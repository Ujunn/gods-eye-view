#!/usr/bin/env node
/**
 * Safe, idempotent installer for the Rice Trade demo layer.
 * Run from the ROOT of an existing gods-eye-view checkout:
 *   node /path/to/gods-eye-rice-trade-demo/apply.mjs
 * Does not run npm, modify credentials, or contact a network.
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const patchRoot = path.dirname(fileURLToPath(import.meta.url));
const repoRoot = process.cwd();
const expectedPackage = path.join(repoRoot, 'package.json');
const catalogPath = 'src/app/constructCatalog.js';
const panelPath = 'src/ui/layerPanel.js';
const backupRoot = path.join(repoRoot, '.rice-trade-patch-backup');

function stop(message) {
  console.error(`\n[ERROR] ${message}\n`);
  process.exit(1);
}
function readRelative(relativePath) {
  const file = path.join(repoRoot, relativePath);
  if (!fs.existsSync(file)) stop(`Missing ${relativePath}. Make sure you are inside gods-eye-view.`);
  return fs.readFileSync(file, 'utf8');
}
function insertOnce(source, marker, anchor, insertion, fileName) {
  if (source.includes(marker)) return source;
  const parts = source.split(anchor);
  if (parts.length !== 2)
    stop(`Cannot find an unambiguous insertion point in ${fileName}. Repository layout may have changed. Nothing was written.`);
  return parts[0] + insertion + parts[1];
}

if (!fs.existsSync(expectedPackage)) stop('Run this script inside the gods-eye-view project folder (package.json not found).');
let pkg;
try { pkg = JSON.parse(fs.readFileSync(expectedPackage, 'utf8')); }
catch { stop('Cannot parse package.json.'); }
if (pkg.name !== 'gods-eye-view') stop(`Expected package gods-eye-view; found ${pkg.name || 'unknown'}.`);

const originalCatalog = readRelative(catalogPath);
const originalPanel = readRelative(panelPath);

let nextCatalog = insertOnce(
  originalCatalog,
  "import { createApplicationRiceTrade } from './layers/riceTrade.js';",
  "import { createApplicationTraffic } from './layers/traffic.js';",
  "import { createApplicationTraffic } from './layers/traffic.js';\nimport { createApplicationRiceTrade } from './layers/riceTrade.js';",
  catalogPath,
);
// The above insertion replaces its own anchor. It should contain only one traffic import.
nextCatalog = insertOnce(
  nextCatalog,
  "Object.freeze({ id: 'rice-trade', disposition: 'local-only' }),",
  "  Object.freeze({ id: 'local-adsb', disposition: 'local-only' }),",
  "  Object.freeze({ id: 'local-adsb', disposition: 'local-only' }),\n  Object.freeze({ id: 'rice-trade', disposition: 'local-only' }),",
  catalogPath,
);
nextCatalog = insertOnce(
  nextCatalog,
  '        createApplicationRiceTrade(),',
  '        createApplicationTraffic({ source: sources.traffic, surface }),',
  '        createApplicationTraffic({ source: sources.traffic, surface }),\n        createApplicationRiceTrade(),',
  catalogPath,
);

const nextPanel = insertOnce(
  originalPanel,
  "    label: 'Trade',\n    ids: ['rice-trade'],",
  "  {\n    label: 'Cameras',",
  "  {\n    label: 'Trade',\n    ids: ['rice-trade'],\n  },\n  {\n    label: 'Cameras',",
  panelPath,
);

const copies = [
  'src/layers/riceTrade/data.js',
  'src/layers/riceTrade/index.js',
  'src/app/layers/riceTrade.js',
];

// Verify every source before modifying anything; never overwrite divergent user files.
for (const rel of copies) {
  const source = path.join(patchRoot, rel);
  const dest = path.join(repoRoot, rel);
  if (!fs.existsSync(source)) stop(`Patch archive is missing ${rel}.`);
  if (fs.existsSync(dest) && !fs.readFileSync(dest).equals(fs.readFileSync(source)))
    stop(`Refusing to overwrite your existing ${rel}. Move it aside or compare first.`);
}

const changes = [
  { rel: catalogPath, before: originalCatalog, after: nextCatalog },
  { rel: panelPath, before: originalPanel, after: nextPanel },
].filter(({ before, after }) => before !== after);

if (changes.length) {
  fs.mkdirSync(backupRoot, { recursive: true });
  for (const { rel, before } of changes) {
    const backup = path.join(backupRoot, rel);
    fs.mkdirSync(path.dirname(backup), { recursive: true });
    // Retain the very first backup across reruns.
    if (!fs.existsSync(backup)) fs.writeFileSync(backup, before);
  }
}
for (const rel of copies) {
  const source = path.join(patchRoot, rel);
  const dest = path.join(repoRoot, rel);
  if (fs.existsSync(dest)) continue;
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  fs.copyFileSync(source, dest);
  console.log(`[COPY] ${rel}`);
}
for (const { rel, after } of changes) {
  fs.writeFileSync(path.join(repoRoot, rel), after);
  console.log(`[EDIT] ${rel}`);
}
if (!changes.length && copies.every(rel => fs.existsSync(path.join(repoRoot, rel))))
  console.log('Rice Trade patch already installed; no additional edits needed.');
console.log('\n[OK] The Rice Trade layer has been wired into the local app.');
console.log('Next run:');
console.log('  npm install world-countries@5.1.0');
console.log('  npm run dev');
console.log('Then open http://localhost:4173, find Data Layers → Trade → Rice Trade (Simulated).');
console.log('Backups, if created: .rice-trade-patch-backup/');
