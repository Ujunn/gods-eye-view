# Rice Trade Simulated — God's Eye View local demo

**Demo only.** 100 independent countries, 200 unique directed flows, annual trade volume 1–500 thousand tonnes, starting seed `20261014`. Every selected country appears in at least one flow. All routes and volumes are synthetic and must not be interpreted as real rice trade or shipping routes.

## The easiest Mac installation

Requirements: Node.js **24.14+ or 26.x** (check `node -v`), npm and Git.

1. Download this ZIP and unzip it in **Downloads**. It contains `gods-eye-rice-trade-demo/apply.mjs`.
2. Open Terminal and run:

   ```bash
   cd ~/Downloads
   git clone https://github.com/bilawalsidhu/gods-eye-view.git
   cd gods-eye-view
   npm ci
   node ~/Downloads/gods-eye-rice-trade-demo/apply.mjs
   npm install world-countries@5.1.0
   npm run dev
   ```

   If you already cloned the repository elsewhere, `cd` to that repository instead of running `git clone` again.
3. Open `http://localhost:4173` and select **Data Layers → Trade → Rice Trade (Simulated)**. Use the **REGENERATE** chip to change the seed and routes.

The installer only copies three JS modules and edits two registration files. It checks the repository name and exact insertion anchors, refuses to overwrite different files, and stores original edits in `.rice-trade-patch-backup`. It does not access the network or install npm packages by itself. The npm commands above do require a network connection.

### Troubleshooting

- `node: command not found` or unsupported version: install Node 24.14+ or 26.x via your preferred version manager, then retry.
- `Cannot find an unambiguous insertion point`: this repository version differs from the checked upstream layout; the installer stops rather than guessing. Use the manual instructions below.
- UI not visible: check your terminal for build/runtime errors, make sure the layer is on, and zoom out to see the whole globe.
- `npm run dev` starts but the layer is missing: restart Vite and hard-refresh the page.

## Manual wiring alternative

1. `npm install world-countries@5.1.0`.
2. Copy the patch's `src/` files into the repository's `src/`.
3. In `src/app/constructCatalog.js`:
   - Add `import { createApplicationRiceTrade } from './layers/riceTrade.js';`
   - Add `Object.freeze({ id: 'rice-trade', disposition: 'local-only' }),` in `LOCAL_ONLY_LAYER_METADATA`.
   - Add `createApplicationRiceTrade(),` to the array passed to `createLayerCatalog` (after traffic is a good choice).
4. In `src/ui/layerPanel.js`, insert `{ label: 'Trade', ids: ['rice-trade'] },` in `PANEL_GROUPS`.
5. Run `npm run check:boundaries`, `npm run build`, `npm test`, `npm run dev`.

This layer is deliberately `local-only`: it does not enter shared URLs or persistent layer-state serialization. Full application and browser runtime testing has **not** been performed on your Mac.

Country centroids come from `world-countries`. Review third-party data licensing before distributing.
