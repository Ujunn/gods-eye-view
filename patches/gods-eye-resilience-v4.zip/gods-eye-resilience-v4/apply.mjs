#!/usr/bin/env node
// Narrow, hash-guarded v4 step-slider patch. Accepts exact v2 or v3 lab source.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const root = process.cwd();
const bundle = path.dirname(fileURLToPath(import.meta.url));
const checkOnly = process.argv.includes('--check');
const relativePath = 'src/ui/resilienceLab.js';
const versions = [
  { label: 'v2', sha: '7b2ad63781c84b17fb9101eb476eabaec35556fa74ccbf86fca7797371a5e07c' },
  { label: 'v3', sha: '207ec61d91254c235a9f1e96a29599ce5c11664e7697c3fe3ab1937cce0ba456' },
];
const sha = data => crypto.createHash('sha256').update(data).digest('hex');
const fail = message => { throw new Error(`[STOP] ${message}。未覆盖本地代码。`); };
try {
  const manifest = path.join(root,'package.json');
  if(!fs.existsSync(manifest))fail('请先进入 gods-eye-view 项目目录');
  const pkg=JSON.parse(fs.readFileSync(manifest,'utf8'));
  if(pkg.name!=='gods-eye-view')fail('当前目录不是 gods-eye-view');
  const dst=path.join(root,relativePath);
  if(!fs.existsSync(dst))fail(`找不到 ${relativePath}，请先安装韧性实验室`);
  const previous=fs.readFileSync(dst);
  const previousHash=sha(previous);
  const patches = versions.map(({label,sha:expected}) => {
    const file=path.join(bundle,'src/ui',`resilienceLab.${label}.js`);
    const next=fs.readFileSync(file);
    return {label,expected,next,nextHash:sha(next)};
  });
  const already=patches.find(p=>p.nextHash===previousHash);
  if(already){console.log(`[OK] v4 步长滑块已安装（基于 ${already.label}）。`);process.exit(0);}
  const matched=patches.find(p=>p.expected===previousHash);
  if(!matched)fail(`当前 ${relativePath} 与 v2/v3 标准版本不同（SHA256 ${previousHash}），为防止覆盖你的手动修改，已停止`);
  console.log(`[OK] 识别本地韧性实验室 ${matched.label}；将修改：${relativePath}`);
  if(checkOnly){console.log('[OK] 预检查完成，没有修改文件。');process.exit(0);}
  const backup=path.join(root,'.resilience-v4-backup',relativePath);
  fs.mkdirSync(path.dirname(backup),{recursive:true});
  if(!fs.existsSync(backup))fs.writeFileSync(backup,previous,{flag:'wx'});
  const tmp=dst+'.v4-tmp';
  fs.writeFileSync(tmp,matched.next);
  fs.renameSync(tmp,dst);
  console.log('[UPDATED] 攻击步长改为 0%～1% 滑块，最小 0.01%，默认 0.20%。');
  console.log('[OK] 保留原有地图样式和攻击算法；不修改 FAOSTAT 或韧性结果 JSON。');
} catch(error){console.error(error.message);process.exitCode=1;}
