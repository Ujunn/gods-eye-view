import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const dir=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const base=path.resolve(dir,'..');
const relative='src/ui/resilienceLab.js';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const run=(cwd,args=[])=>spawnSync(process.execPath,[path.join(dir,'apply.mjs'),...args],{cwd,encoding:'utf8'});
const source=(version)=>path.join(base,`gods-eye-resilience-${version}`,relative);
const build=(version)=>path.join(dir,'src/ui',`resilienceLab.${version}.js`);
for(const version of ['v2','v3']){
  const sourceText=fs.readFileSync(build(version),'utf8');
  assert.match(sourceText,/stepSelect\.type='range'/);
  assert.match(sourceText,/stepSelect\.min='0';stepSelect\.max='1';stepSelect\.step='0\.01'/);
  assert.match(sourceText,/play\.disabled=stepSize===0/);
  assert.match(sourceText,/removedAtCurrentPercent/);
  assert.match(sourceText,/slider\.step='0\.01'/);
  assert.doesNotMatch(sourceText,/ATTACK_STEPS|stepIndex|updateSliderScale/);

  const root=fs.mkdtempSync(path.join(os.tmpdir(),`gev-step-v4-${version}-`));
  try{
    fs.writeFileSync(path.join(root,'package.json'),JSON.stringify({name:'gods-eye-view'}));
    fs.mkdirSync(path.join(root,'src/ui'),{recursive:true});
    const dst=path.join(root,relative);
    fs.copyFileSync(source(version),dst);
    const oldHash=sha(fs.readFileSync(dst));
    const pre=run(root,['--check']);assert.equal(pre.status,0,pre.stderr);
    assert.equal(sha(fs.readFileSync(dst)),oldHash);
    const installed=run(root);assert.equal(installed.status,0,installed.stderr);
    assert.equal(sha(fs.readFileSync(dst)),sha(fs.readFileSync(build(version))));
    assert.equal(sha(fs.readFileSync(path.join(root,'.resilience-v4-backup',relative))),oldHash);
    assert.equal(run(root).status,0,'idempotence');
    fs.appendFileSync(dst,'\n// local customizations must be protected\n');
    const changedHash=sha(fs.readFileSync(dst));
    const aborted=run(root);assert.notEqual(aborted.status,0,'tamper guard');
    assert.equal(sha(fs.readFileSync(dst)),changedHash);
  } finally{fs.rmSync(root,{recursive:true,force:true});}
}
for(const count of [185,1472]){
  const removed=pct=>Math.min(count,Math.floor((count*pct)/100+1e-9));
  assert.equal(removed(0),0);
  assert.equal(removed(100),count);
  for(let x=0;x<100;x+=.01)assert.ok(removed(x+.01)>=removed(x));
}
assert.equal(Math.floor(1472*.08/100+1e-9),1);
assert.equal(Math.floor(185*.50/100+1e-9),0);
console.log('v4 checks passed: v2/v3 compatibility, 0.01% attack steps, discrete edge-count precision, guard, idempotence, backups.');
