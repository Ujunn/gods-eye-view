# God's Eye View · 韧性实验室 v4：攻击步长精调滑块

基于你已经运行的 `gods-eye-view` 本地项目安装。**只改 `src/ui/resilienceLab.js` 一个文件**，不改四种农产品贸易数据、攻击结果 JSON、相机环绕、线宽或 GitHub 历史。

## 改动

- 原来的 `0.2 / 0.3 / 0.5 / 0.7%` 下拉列表，换成 **0.00%～1.00%** 的二级滑块。
- 每次微调为 **0.01%**，默认 **0.20%**。旁边实时显示选择的步长。
- **0.00% 表示仅手动**：禁用自动播放，仍可自由拖动攻击程度滑块。调回非零即可恢复播放。
- 攻击程度滑块显示 **两位小数**；按键盘左右键按选定步长微调。播放时按选定步长推进。
- **地图上的攻击对象**按 `floor(原始节点或边总数 × 当前攻击百分比 / 100)` 实际增减，避免精细百分比只是显示数字；拖动幅度不足以删掉一个节点/边时，地图保持不变是数学上正确的。
- **重要限制**：六项韧性指标和大号网络效率保留率仍然使用最接近的 **整数百分点预计算快照**。因此屏幕上的精细攻击程度不意味着指标精度同步提高。指标卡和状态文字会明确标注使用的整百分比快照。要做到指标随每一个节点/边的删除精确变化，下一阶段需要重算更密集的仿真快照。

## 安装

解压 ZIP 到 `~/Downloads/gods-eye-resilience-v4`，先在运行 `npm run dev` 的终端按 `Control+C`，再执行：

```bash
cd ~/Downloads/gods-eye-view
node ~/Downloads/gods-eye-resilience-v4/apply.mjs --check
node ~/Downloads/gods-eye-resilience-v4/apply.mjs
npm run build
npm run dev
```

刷新 http://localhost:4173 ，展开右侧 NETWORK RESILIENCE LAB 查看新的步长滑块。

安装程序识别已安装的 v2 或 v3 韧性实验室，并分别保留对应的攻击红线视觉方案。修改前会备份旧文件到 `.resilience-v4-backup/`。重复安装安全。如果你手动改过此文件，脚本会停止，不会强行覆盖。

## 验收建议

1. 调节步长：从 `0.20%` → `0.07%` → `0.01%`，右侧实时显示准确。
2. 攻击程度从 `0.00%` 推进到 `0.08%`，观察“边攻击”下的首次贸易边失效。总共约 1472 条边，每条边约占 0.068%，因此不是每 0.01% 都一定改变地图。
3. 选择“节点攻击”时，185 个国家每个约占 0.54%，所以出现更长的无变化区间是正常的。
4. 步长设为 `0.00%` 后播放按钮不可用，但仍可手动拖动主攻击滑块。
5. 六项指标仍显示相应的整百分点快照，这不是本次补丁的遗漏，而是目前已生成的 101 步仿真数据的分辨率限制。

## GitHub

确认本地效果满意后再提交：

```bash
cd ~/Downloads/gods-eye-view
git status --short
git add src/ui/resilienceLab.js
git diff --cached --stat
git commit -m "feat: add fine-grained attack step slider"
git push ujunn agri-trade-2022
```

注意：如果 v2/v3 还没有推送 GitHub，还需要核查并单独 `git add` 它们增加的其它模块。不要直接 `git add .`，避免误上传备份或数据缓存。
