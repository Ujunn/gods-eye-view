#!/usr/bin/env node
/** Safe, hash-guarded patch for the four-crop + resilience setup. No network. */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const repo = process.cwd();
const bundle = path.dirname(fileURLToPath(import.meta.url));
const inspection = process.argv.includes('--check');
const files = [
  {
    path: 'src/ui/earthSpin.js',
    oldHash: '94a4cdb32d24e9e103e2a995813fec7af33a8bb523561409e06756ff38dd6bc0',
  },
  {
    path: 'src/layers/agriTrade/index.js',
    oldHash: '3b450a04427dbfcfd368e0948385c4fea0d7c18918d03382b19b39993ed46884',
  },
  {
    path: 'src/ui/resilienceLab.js',
    oldHash: 'a9b88be755e17485c33367c6c0aaa950c285ba5cce25403a2d108f642eeb672d',
  },
];
function sha(data){return crypto.createHash('sha256').update(data).digest('hex');}
function fail(msg){throw new Error(`[STOP] ${msg}；未覆盖任何源文件。`);}
function requireFile(file){if(!fs.existsSync(file))fail(`文件不存在：${file}`);return fs.readFileSync(file);}
try {
  const pkg = JSON.parse(requireFile(path.join(repo,'package.json')).toString());
  if(pkg.name!=='gods-eye-view')fail('请先进入 Gods Eye View 项目目录');
  const main = requireFile(path.join(repo,'src/main.js')).toString();
  if(!main.includes('installEarthSpin')||!main.includes('installResilienceLab'))
    fail('需要先安装地球环绕模块和韧性实验室第一阶段');
  const changed=[];
  for(const item of files){
    const present=requireFile(path.join(repo,item.path));
    const next=requireFile(path.join(bundle,item.path));
    const currentHash=sha(present), desiredHash=sha(next);
    if(currentHash===desiredHash)continue;
    if(currentHash!==item.oldHash)fail(`${item.path} 与上一版不一致，可能有手动修改，请先保留差异`);
    changed.push({...item,present,next});
  }
  if(!changed.length){console.log('[OK] v2 已安装，无需重复修改。');process.exit(0);}
  if(inspection){
    console.log('[OK] 版本核对通过，待更新文件：');
    for(const item of changed) console.log('  ',item.path);
    process.exit(0);
  }
  const backup=path.join(repo,'.resilience-v2-backup');
  for(const item of changed){
    const target=path.join(backup,item.path);
    fs.mkdirSync(path.dirname(target),{recursive:true});
    if(!fs.existsSync(target))fs.writeFileSync(target,item.present);
  }
  for(const item of changed){
    const target=path.join(repo,item.path);
    const temp=target+'.resilience-v2-tmp';
    fs.writeFileSync(temp,item.next);
    fs.renameSync(temp,target);
    console.log('[UPDATED]',item.path);
  }
  console.log('[OK] v2：攻击步长、实线加粗、方向染红、最佳视角、地轴环绕已安装');
  console.log('请运行 npm run build && npm run dev 并在浏览器验收。');
}catch(error){console.error(error.message);process.exitCode=1;}
