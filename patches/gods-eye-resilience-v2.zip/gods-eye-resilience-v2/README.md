# God's Eye View · Resilience Lab v2 补丁

针对用户当前可运行的 `Ujunn/gods-eye-view` / `agri-trade-2022` 项目；要求已安装四农产品贸易可视化、线路数量滑块、地轴自转和第一阶段大豆韧性实验室。

## 改动

1. **攻击程度二级选项**：可选择 `0.2% / 0.3% / 0.5% / 0.7%`，默认 `0.5%`。滑块及播放按选中步长推进，末端可以到达严格的 `100%`。**注意：后台现有 FAOSTAT 仿真仍是每个整数百分点一个计算快照**，小数滑块使用最近的整数快照；底部显示当前对应的计算快照百分比，避免把细粒度播放误认为高分辨率重算。如需每 0.2% 真正重新计算网络指标，需要单独升级计算引擎。
2. **四作物贸易图层实线加粗**：将 `PolylineGlowMaterialProperty` 改为 `ColorMaterialProperty`，线宽依贸易量调整（约 `2.6–6.4px`），取消浮白边缘，箭头的白色勾边也移除。仍保留沿弧线移动的作物色箭头。
3. **韧性实验室的被攻击线路染红**：正常大豆线为实心紫色（约 `3.2–5.4px`），攻击时红色实线（再加粗约 2.8px）从主要出口国方向向进口国方向在约 0.95 秒内逐步覆盖原紫色线；未被攻击的线仍显示原色。红色仅表示结构失效。修改了生成仿真结果的 `prepare.py`：计算图仍按论文原型构建为**无向双边贸易关系**，动画方向选择这对国家中统计贸易量更大的出口方向，不代表双向关系只有这一种流向，更不是实际经过多国的运输线路。
4. **最佳视角**：韧性实验室面板的「◎ 最佳视角」按钮，镜头飞到推荐的全球视角。若当前自动环绕开启，将暂停环绕约 2.6 秒，镜头飞行结束后继续。
5. **相机绕地轴环绕**：使用 `Camera.setView` 对 ECEF 相机位置、方向、上向量做 Z 轴旋转；不修改地球/贸易节点/星体的真实坐标。为避免星空、太阳和月亮随着镜头运动造成眩晕，**开启环绕时暂时隐藏 Cesium skyBox/sun/moon**，关闭环绕时恢复之前的可见性。其他可能由项目自己添加的星体图层未单独处理。保留手动拖拽暂停、松开恢复及速度二级滑块。

## Mac 安装（不删除你的真实数据）

1. 下载 ZIP、双击解压，把整个 `gods-eye-resilience-v2` 放到 `~/Downloads/`。
2. 若开发服务器正在运行，按 `Control + C` 先停止。
3. 终端执行：

```bash
cd ~/Downloads/gods-eye-view
bash ~/Downloads/gods-eye-resilience-v2/run_on_mac.sh
npm run dev
```

在浏览器访问 `http://localhost:4173`，按 `Command + Shift + R` 强制刷新。

该命令会检查原始版本文件是否符合此前安装包、先运行 Python 单元测试、使用已经生成的 `soybeans_full.csv` 重新计算大豆实验 JSON、增量替换三个 JS 文件，然后运行 `npm run build`。

**不需要**重新下载 FAOSTAT ZIP，更不需要重新扫描原始 5200 万行。**不会**自动提交或推送 GitHub。

若大豆完整 CSV 路径不同，可改为：

```bash
bash ~/Downloads/gods-eye-resilience-v2/run_on_mac.sh "/实际路径/soybeans_full.csv" "/实际路径/country_centroids_m49.json"
```

### 安全机制

- 版本检查使用 3 个上一版源文件的 SHA-256。如果你手工改过，安装器会 `[STOP]`，避免覆盖。
- 原文件保存在 `~/Downloads/gods-eye-view/.resilience-v2-backup/`，旧的大豆实验 JSON 也会在那里留一份备份。
- 四个 `public/data/trade/*_2022.json` 不受修改；其他农产品的数据清洗结果不受修改。
- 备份目录**不要提交到 GitHub**。

### 本地验收建议

1. `NETWORK RESILIENCE LAB` 面板右上角，攻击百分比可在 0.2/0.3/0.5/0.7 四档变化；确认 `100%` 可达。
2. 将滑块从 0% 推到 10%，观察紫色线沿出口方向逐渐被红色较粗的实线覆盖；反向拖动会恢复紫色。
3. 关闭实验室后查看四种农产品原图层，确认已全部变成单色加粗实线，没有发光白边。
4. 打开「镜头环绕」，拖拽地球并松开；应从新视角继续绕地轴运行，不应该带着太阳、月亮和默认星空转。
5. 点击「◎ 最佳视角」，确认相机平滑回到全球概览；镜头环绕开着时不应抖动或和相机动画打架。

### 说明

- 算法仍是论文的**四种攻击策略 + 六项网络指标的 FAOSTAT 实现**。网络并未进行真实物流重分配。`R_E` 使用当前预计算快照网络效率除以 0% 初始网络效率。
- 本包已验证 JS 语法、Python 小样本、安装器重复执行与备份/修改保护；**尚未在你的 Mac 实际运行 Cesium/Vite 浏览器测试**。
- 如果 `npm run build` 失败，请保留报错信息，不要先覆盖其他文件。

## 提交到 Ujunn 分支（本地验证成功后才操作）

```bash
cd ~/Downloads/gods-eye-view
git status --short
git add src/ui/earthSpin.js src/layers/agriTrade/index.js src/ui/resilienceLab.js public/data/resilience/soybeans_2022_lab.json src/main.js
git diff --cached --stat
git commit -m "feat: refine resilience controls and trade attack visuals"
git push ujunn agri-trade-2022
```

如果 `src/main.js` 已提交且未改变，`git add` 不会增加它。**不要运行 `git add .`**，以免上传之前的备份文件、缓存或原始大数据。
