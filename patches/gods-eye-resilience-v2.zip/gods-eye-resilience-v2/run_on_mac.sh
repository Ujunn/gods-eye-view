#!/bin/bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
REPO="${GEV_REPO:-$HOME/Downloads/gods-eye-view}"
WORK="$HOME/Downloads/faostat-2022-trade-extractor"
INPUT="${1:-$WORK/output/cleaned/soybeans_full.csv}"
COORDS="${2:-$WORK/country_centroids_m49.json}"
if [[ ! -f "$INPUT" ]]; then echo "[STOP] 找不到完整大豆 CSV: $INPUT" >&2; exit 1; fi
if [[ ! -f "$COORDS" ]]; then echo "[STOP] 找不到国家坐标文件: $COORDS" >&2; exit 1; fi
if [[ ! -f "$REPO/package.json" ]]; then echo "[STOP] 找不到项目: $REPO" >&2; exit 1; fi
cd "$REPO"
node "$HERE/apply.mjs" --check
python3 "$HERE/tests/test_prepare.py"
DEST="$REPO/public/data/resilience/soybeans_2022_lab.json"
if [[ -f "$DEST" && ! -f "$REPO/.resilience-v2-backup/soybeans_2022_lab.json" ]]; then
  mkdir -p "$REPO/.resilience-v2-backup"
  cp "$DEST" "$REPO/.resilience-v2-backup/soybeans_2022_lab.json"
fi
python3 "$HERE/prepare.py" --input "$INPUT" --coords "$COORDS" --output "$DEST"
node "$HERE/apply.mjs"
npm run build
printf '\n[OK] v2 安装完成。启动：cd "%s" && npm run dev\n' "$REPO"
