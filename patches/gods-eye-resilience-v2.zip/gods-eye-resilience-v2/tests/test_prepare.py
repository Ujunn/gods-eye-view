import csv
import importlib.util
import json
from pathlib import Path
from tempfile import TemporaryDirectory

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('sim',ROOT/'prepare.py')
sim=importlib.util.module_from_spec(spec)
spec.loader.exec_module(sim)

with TemporaryDirectory() as root:
    root=Path(root)
    countries={f'{i:03d}':dict(name=f'N{i}',iso3=f'T{i:02d}',lon=15*i,lat=15) for i in range(1,7)}
    coords=root/'coords.json';coords.write_text(json.dumps(countries))
    file=root/'soybeans_full.csv'
    columns=['exporter_m49','importer_m49','exporter_name','importer_name','volume_tonnes']
    rows=[('001','002',100),('002','003',70),('003','004',50),('004','005',20),('005','006',10),('001','006',5),('002','005',2)]
    with file.open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=columns);writer.writeheader()
        for a,b,v in rows:
            writer.writerow(dict(exporter_m49=a,importer_m49=b,exporter_name=a,importer_name=b,volume_tonnes=v))
    nodes,edges,skipped=sim.build_graph(file,coords)
    assert len(nodes)==6 and len(edges)==len(rows) and skipped==0
    assert next(e for e in edges if e['id']=='001|002')['source']=='001'
    assert next(e for e in edges if e['id']=='001|002')['target']=='002'
    experiments=sim.precompute(nodes,edges,seed=3)
    assert len(experiments)==4
    for strategy in experiments.values():
        assert len(strategy['steps'])==101
        assert strategy['steps'][0]['metrics']['efficiencyRetentionPct']==100
        assert strategy['steps'][-1]['metrics']['efficiencyRetentionPct']==0
        assert strategy['steps'][-1]['metrics']['giantFraction'] <= 1/6+1e-6
        assert strategy['steps'][-1]['metrics']['isolatedFraction']==1
        retention=[s['metrics']['efficiencyRetentionPct'] for s in strategy['steps']]
        assert all(earlier+1e-6 >= later for earlier,later in zip(retention,retention[1:])),retention
    assert sim.precompute(nodes,edges,seed=3)['node-random']['order'] == experiments['node-random']['order']
    assert sim.precompute(nodes,edges,seed=4)['node-random']['order'] != experiments['node-random']['order']
print('PASS: bilateral graph, four attack methods, endpoints, monotonic efficiency, deterministic random seed')
