import importlib.util,json,csv
from tempfile import TemporaryDirectory
from pathlib import Path
script=Path(__file__).resolve().parents[1]/'prepare.py'
spec=importlib.util.spec_from_file_location('sim',script)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
with TemporaryDirectory() as td:
    root=Path(td)
    pos={str(i).zfill(3):{'name':str(i),'iso3':'AAA','lat':i*3,'lon':i*5} for i in range(1,5)}
    (root/'coords.json').write_text(json.dumps(pos))
    with (root/'full.csv').open('w',newline='') as out:
        w=csv.DictWriter(out,fieldnames=['exporter_m49','importer_m49','exporter_name','importer_name','volume_tonnes']);w.writeheader()
        for a,b,v in [('001','002',15),('002','001',90),('003','004',80),('004','001',20)]:
            w.writerow(dict(exporter_m49=a,importer_m49=b,exporter_name=a,importer_name=b,volume_tonnes=v))
    nodes,edges,skipped=m.build_graph(root/'full.csv',root/'coords.json')
    assert len(nodes)==4 and len(edges)==3 and skipped==0
    edge=next(x for x in edges if x['id']=='001|002')
    assert edge['source']=='002' and edge['target']=='001' and edge['volumeTonnes']==105 and edge['dominantExportTonnes']==90, edge
    assert [e['volumeTonnes'] for e in edges]==[105,80,20]
    for step in [0.2,0.3,0.5,0.7]:
        max_index=__import__('math').ceil(100/step)
        prev=-1
        for index in range(max_index+1):
            pct=min(100,round(index*step,1))
            assert 0<=pct<=100 and pct>=prev
            assert round(pct)<=100
            prev=pct
        assert pct==100
print('PASS: real dominant export direction, undirected graph ID, sortable volume, slider step end points')
