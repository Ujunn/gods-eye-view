#!/usr/bin/env node
/** Add the standalone Earth Spin UI with a single, reversible src/main.js edit. */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const project = process.cwd();
const patchDir = path.dirname(fileURLToPath(import.meta.url));
const mainPath = path.join(project, 'src/main.js');
const modulePath = path.join(project, 'src/ui/earthSpin.js');
const sourceModule = path.join(patchDir, 'src/ui/earthSpin.js');
const backupPath = path.join(project, '.earth-spin-backup/src/main.js');

function fail(message) {
  console.error(`[STOP] ${message}`);
  process.exitCode = 1;
}

if (!fs.existsSync(path.join(project, 'package.json')) ||
    JSON.parse(fs.readFileSync(path.join(project, 'package.json'), 'utf8')).name !== 'gods-eye-view') {
  fail('请先 cd 到 gods-eye-view 项目根目录。');
} else if (!fs.existsSync(mainPath) || !fs.existsSync(sourceModule)) {
  fail('找不到主程序或补丁模块，检查是否正确解压 ZIP。');
} else {
  const before = fs.readFileSync(mainPath, 'utf8');
  const importMark = "import { describeError } from './standalone/errors.js';";
  const startMark = 'application.start().catch((error) => {';
  const newImport = "import { installEarthSpin } from './ui/earthSpin.js';";
  const newStart = `application.start().then(({ scene }) => {\n  const cleanupSpin = installEarthSpin(scene.viewer);\n  let unsubscribe = () => {};\n  unsubscribe = application.subscribe(({ status }) => {\n    if (status === 'destroying' || status === 'destroyed' || status === 'failed') {\n      cleanupSpin();\n      unsubscribe();\n    }\n  });\n}).catch((error) => {`;
  const alreadyInstalled = before.includes(newImport) && before.includes('const cleanupSpin = installEarthSpin(scene.viewer);');
  const existingEdited = fs.existsSync(modulePath) &&
    !fs.readFileSync(modulePath).equals(fs.readFileSync(sourceModule));

  if (existingEdited) {
    fail('现有 src/ui/earthSpin.js 不同，拒绝覆盖用户代码。');
  } else if (!alreadyInstalled &&
    (!before.includes(importMark) || !before.includes(startMark) ||
     before.split(importMark).length !== 2 || before.split(startMark).length !== 2 ||
     before.includes(newImport))) {
    fail('当前 src/main.js 与预期结构不匹配，未修改任何项目文件。');
  } else {
    if (!alreadyInstalled) {
      const after = before
        .replace(importMark, `${importMark}\n${newImport}`)
        .replace(startMark, newStart);
      fs.mkdirSync(path.dirname(backupPath), { recursive: true });
      if (!fs.existsSync(backupPath)) fs.writeFileSync(backupPath, before);
      fs.mkdirSync(path.dirname(modulePath), { recursive: true });
      if (!fs.existsSync(modulePath)) fs.copyFileSync(sourceModule, modulePath);
      fs.writeFileSync(mainPath, after);
      console.log('[OK] 已修改 src/main.js，并备份原文件。');
    } else if (!fs.existsSync(modulePath)) {
      fs.copyFileSync(sourceModule, modulePath);
      console.log('[OK] 已补全缺失的自转模块。');
    } else {
      console.log('[OK] 已安装过，不需要重复修改。');
    }
    console.log('下一步：npm run dev，在页面右下角点击「地球自转」。');
  }
}
