import * as Cesium from 'cesium';
import {
  holdContinuousRender,
  releaseContinuousRender,
} from '../renderGovernor.js';

// Five seconds per full visual rotation. Change to 15000 for a slower 15s rotation.
export const EARTH_SPIN_PERIOD_MS = 5000;
const RENDER_OWNER = 'earth-auto-spin';
const POINTER_RESUME_DELAY_MS = 250;
const MAX_FRAME_DELTA_MS = 80;

/**
 * A globe-scale *visual* spin. Cesium's globe and geographic data stay fixed;
 * the camera orbits Earth's ECEF Z axis so existing data layers remain aligned.
 * Manual dragging takes precedence, and releasing resumes from the new view.
 *
 * @param {import('cesium').Viewer} viewer
 * @returns {() => void} cleanup
 */
export function installEarthSpin(viewer) {
  if (!viewer?.scene || !viewer?.camera || !viewer?.container) {
    throw new TypeError('installEarthSpin requires a Cesium Viewer');
  }
  if (document.getElementById('gev-earth-spin-toggle')) {
    throw new Error('Earth-spin button already exists');
  }

  let enabled = false;
  let destroyed = false;
  let lastTime = 0;
  let resumeAfter = 0;
  const heldPointers = new Set();
  let removeFrameListener = null;

  const button = document.createElement('button');
  button.id = 'gev-earth-spin-toggle';
  button.type = 'button';
  button.title = '模拟地球自转 · 5 秒一圈 · 拖拽时暂停，松开后自动继续';
  button.setAttribute('aria-label', '切换地球自转');
  button.style.cssText = [
    'position:fixed',
    'right:20px',
    'bottom:90px',
    'z-index:2500',
    'min-height:37px',
    'padding:8px 14px',
    'border:1px solid rgba(65,216,245,.5)',
    'border-radius:8px',
    'background:rgba(3,14,26,.92)',
    'color:#92d9e6',
    'font:600 12px/1.4 ui-monospace,SFMono-Regular,Menlo,monospace',
    'letter-spacing:.04em',
    'cursor:pointer',
    'box-shadow:0 0 14px rgba(25,182,230,.17)',
  ].join(';');

  function syncButton() {
    button.textContent = enabled ? '⟳ 地球自转 · ON' : '⟳ 地球自转 · OFF';
    button.setAttribute('aria-pressed', String(enabled));
    button.style.borderColor = enabled
      ? 'rgba(79,244,228,.95)'
      : 'rgba(65,216,245,.5)';
    button.style.color = enabled ? '#7fffe2' : '#92d9e6';
  }

  function tick() {
    const now = performance.now();
    if (!lastTime) lastTime = now;
    const elapsed = Math.min(MAX_FRAME_DELTA_MS, Math.max(0, now - lastTime));
    lastTime = now;

    if (!enabled || destroyed || viewer.isDestroyed?.()) return;
    if (heldPointers.size || now < resumeAfter) return;
    if (viewer.scene.mode !== Cesium.SceneMode.SCENE3D) return;
    if (viewer.trackedEntity) return; // Let tracked targets own the camera.

    const camera = viewer.camera;
    // Another feature may own a local reference frame (e.g. target orbit).
    // Never rotate around the wrong center or steal that camera authority.
    if (!Cesium.Matrix4.equals(camera.transform, Cesium.Matrix4.IDENTITY)) return;

    const radians = (-2 * Math.PI * elapsed) / EARTH_SPIN_PERIOD_MS;
    if (radians !== 0) {
      camera.rotate(Cesium.Cartesian3.UNIT_Z, radians);
    }
  }

  function setEnabled(next) {
    if (destroyed || enabled === next) return;
    enabled = next;
    lastTime = 0;
    if (enabled) {
      // Preserve the on-screen view while setting Earth-center orbit origin.
      // Do not disturb an active tracked entity.
      if (!viewer.trackedEntity && viewer.scene.mode === Cesium.SceneMode.SCENE3D) {
        viewer.camera.lookAtTransform(Cesium.Matrix4.IDENTITY);
      }
      removeFrameListener = viewer.scene.preRender.addEventListener(tick);
      holdContinuousRender(RENDER_OWNER);
    } else {
      if (removeFrameListener) removeFrameListener();
      removeFrameListener = null;
      releaseContinuousRender(RENDER_OWNER);
    }
    syncButton();
  }

  function onDown(event) {
    heldPointers.add(event.pointerId);
  }
  function onUp(event) {
    heldPointers.delete(event.pointerId);
    resumeAfter = performance.now() + POINTER_RESUME_DELAY_MS;
    lastTime = 0;
  }
  function pauseBriefly() {
    resumeAfter = performance.now() + POINTER_RESUME_DELAY_MS;
    lastTime = 0;
  }
  function onBlur() {
    heldPointers.clear();
    pauseBriefly();
  }
  function onToggle() {
    setEnabled(!enabled);
  }

  button.addEventListener('click', onToggle);
  viewer.container.addEventListener('pointerdown', onDown, true);
  window.addEventListener('pointerup', onUp, true);
  window.addEventListener('pointercancel', onUp, true);
  window.addEventListener('blur', onBlur);
  viewer.container.addEventListener('wheel', pauseBriefly, { capture: true, passive: true });
  document.body.appendChild(button);
  syncButton();

  return function destroy() {
    if (destroyed) return;
    setEnabled(false);
    destroyed = true;
    button.removeEventListener('click', onToggle);
    viewer.container.removeEventListener('pointerdown', onDown, true);
    window.removeEventListener('pointerup', onUp, true);
    window.removeEventListener('pointercancel', onUp, true);
    window.removeEventListener('blur', onBlur);
    viewer.container.removeEventListener('wheel', pauseBriefly, true);
    button.remove();
  };
}
