# God's Eye View · 地球自转按钮

## 安装

把 `gods-eye-earth-spin` 解压到 Mac 下载文件夹，然后运行：

```bash
cd ~/Downloads/gods-eye-view
node ~/Downloads/gods-eye-earth-spin/apply.mjs
npm run build
npm run dev
```

打开 http://localhost:4173，右下角找到 `⟳ 地球自转 · OFF`，点击开启。

- 旋转周期：5 秒一圈；只在 3D 模式、未追踪实体时工作。
- 鼠标拖拽：按下时停止自动旋转；释放 250 ms 后继续旋转，从新的视角出发，不重置视角。
- 滚轮缩放：临时暂停 250 ms 后继续。
- 关闭：保持当前摄像机位置和方向。
- 修改速度：编辑 `src/ui/earthSpin.js` 的 `EARTH_SPIN_PERIOD_MS`。例如 `15000` 就是 15 秒一圈。

## 技术说明

Cesium 的 Globe、地形、3D Tiles 和贸易线都固定在 ECEF/WGS84 坐标系。这个功能不修改场景实体；用 `camera.rotate(Cesium.Cartesian3.UNIT_Z, radians)` 围绕地球自转轴移动摄像机，模拟地球在画面中旋转。**不是在世界坐标中静止摄像机并真正旋转地球。**

使用 `scene.preRender` 配合项目现有 `holdContinuousRender`，避免渲染节能机制让自转停住。使用 `pointerdown`/`pointerup` 暂停与恢复，不在拖拽后把视角重置到某个预设值。与已有追踪/其他摄像机控制功能可能冲突；建议不要同时启用原项目的 O 轨道环绕。

## 卸载

关闭开发服务器（Control+C），在项目根目录执行：

```bash
cp .earth-spin-backup/src/main.js src/main.js
rm -f src/ui/earthSpin.js
```

如果安装后又手动修改过 `src/main.js`，请先比较备份再恢复，以免丢失后来的修改。

## 验证

```bash
node --check src/main.js
node --check src/ui/earthSpin.js
npm run build
```

该安装脚本只修改 `src/main.js` 和新增 `src/ui/earthSpin.js`，不会覆盖四种农产品贸易图层、JSON 数据或私人密钥。安装脚本支持重复执行，会先检查目标文件，以避免意外覆盖。
