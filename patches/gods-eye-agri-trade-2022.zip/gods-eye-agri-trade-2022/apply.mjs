#!/usr/bin/env node
/**
 * Install four FAOSTAT 2022 agri-trade layers into an existing God's Eye View.
 * Only changes three project files, preserves the original simulated Rice layer,
 * and never touches user secrets or installs dependencies.
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = process.cwd();
const sourceRoot = path.dirname(fileURLToPath(import.meta.url));
const catalogPath = 'src/app/constructCatalog.js';
const panelPath = 'src/ui/layerPanel.js';
const backup = '.agri-trade-2022-backup';
const crops = ['rice', 'wheat', 'maize', 'soybeans'];
const layerIds = crops.map((crop) => `agri-${crop}-2022`);

function fail(message) {
  console.error(`\n[STOP] ${message}\nNo project files were changed by this run.`);
  process.exit(1);
}
function full(rel) { return path.join(root, rel); }
function read(rel) {
  if (!fs.existsSync(full(rel))) fail(`Missing ${rel}; run inside gods-eye-view`);
  return fs.readFileSync(full(rel), 'utf8');
}
function insertAfterOne(text, anchor, addition, filename) {
  if (text.includes(addition.trim())) return text;
  const first = text.indexOf(anchor);
  if (first < 0 || text.indexOf(anchor, first + anchor.length) >= 0)
    fail(`Cannot safely locate unique anchor in ${filename}: ${anchor}`);
  return text.slice(0, first + anchor.length) + addition + text.slice(first + anchor.length);
}

const pkg = JSON.parse(read('package.json'));
if (pkg.name !== 'gods-eye-view') fail('package.json is not from gods-eye-view');
const beforeCatalog = read(catalogPath);
const beforePanel = read(panelPath);
const importLine = "import { createApplicationTraffic } from './layers/traffic.js';";
const newImport = "import { createApplicationAgriTrade } from './layers/agriTrade.js';";
let catalog = insertAfterOne(beforeCatalog, importLine, `\n${newImport}`, catalogPath);
const metadataAnchor = "  Object.freeze({ id: 'local-adsb', disposition: 'local-only' }),";
for (const id of layerIds) {
  const line = `  Object.freeze({ id: '${id}', disposition: 'local-only' }),`;
  if (!catalog.includes(line))
    catalog = insertAfterOne(catalog, metadataAnchor, `\n${line}`, catalogPath);
}
const tradeAnchor = '        createApplicationTraffic({ source: sources.traffic, surface }),';
const newTradeEntries = crops.map((crop) => `        createApplicationAgriTrade('${crop}'),`).join('\n');
if (!catalog.includes("createApplicationAgriTrade('rice')"))
  catalog = insertAfterOne(catalog, tradeAnchor, `\n${newTradeEntries}`, catalogPath);

// The first simulated demo installer has already added a Trade group on this Mac.
// Keep it and append the four real layers, rather than creating duplicate groups.
const tradeGroup = /\{\s*label:\s*'Trade',\s*ids:\s*\[([^\]]*)\]\s*,?\s*\}/g;
let panel = beforePanel;
const matches = [...panel.matchAll(tradeGroup)];
if (matches.length > 1) fail('Multiple Trade panel groups found');
if (matches.length === 1) {
  const old = matches[0][0];
  const existing = [...matches[0][1].matchAll(/'([^']+)'/g)].map((x) => x[1]);
  const updated = [...new Set([...existing, ...layerIds])];
  const replacement = `{ label: 'Trade', ids: [${updated.map((v) => `'${v}'`).join(', ')}] }`;
  panel = panel.replace(old, replacement);
} else {
  const camerasAnchor = "  {\n    label: 'Cameras',";
  const block = `  { label: 'Trade', ids: [${layerIds.map((v) => `'${v}'`).join(', ')}] },\n`;
  if (!panel.includes(block.trim())) {
    const first = panel.indexOf(camerasAnchor);
    if (first < 0 || panel.indexOf(camerasAnchor, first + camerasAnchor.length) >= 0)
      fail('Cannot safely locate Cameras panel group');
    panel = panel.slice(0, first) + block + panel.slice(first);
  }
}

const copies = [
  'src/layers/agriTrade/index.js',
  'src/app/layers/agriTrade.js',
];
for (const rel of copies) {
  const from = path.join(sourceRoot, rel);
  const to = full(rel);
  if (!fs.existsSync(from)) fail(`Missing patch source ${rel}`);
  if (fs.existsSync(to) && !fs.readFileSync(to).equals(fs.readFileSync(from)))
    fail(`Refusing to overwrite an edited project file: ${rel}`);
}
const changes = [
  { path: catalogPath, before: beforeCatalog, after: catalog },
  { path: panelPath, before: beforePanel, after: panel },
].filter(({ before, after }) => before !== after);
for (const { path: rel, before } of changes) {
  const dest = full(`${backup}/${rel}`);
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  if (!fs.existsSync(dest)) fs.writeFileSync(dest, before);
}
for (const rel of copies) {
  const dest = full(rel);
  if (fs.existsSync(dest)) continue;
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  fs.copyFileSync(path.join(sourceRoot, rel), dest);
  console.log(`[COPY] ${rel}`);
}
for (const { path: rel, after } of changes) {
  fs.writeFileSync(full(rel), after);
  console.log(`[EDIT] ${rel}`);
}
console.log('\n[OK] Four real-data trade layers installed. Original simulated rice layer preserved.');
console.log('Next: copy the four *_2022.json files to gods-eye-view/public/data/trade/');
console.log('Then: npm run dev');
