# God's Eye View · 2022 FAOSTAT agricultural trade layers

Adds **four independent real-data layers** to the existing 3D globe:
Rice `#35D0FF`, Wheat `#F6C445`, Maize `#7ED957`, Soybeans `#B57CFF`.
The data is **NOT bundled**. Only the four JSON files produced by your FAOSTAT
extractor will be displayed; missing files raise an error, never synthetic data.

## Install on Mac

1. Unzip this archive into `~/Downloads/gods-eye-agri-trade-2022/`.
2. In Terminal:

```bash
cd ~/Downloads/gods-eye-view
node ~/Downloads/gods-eye-agri-trade-2022/apply.mjs
mkdir -p public/data/trade
cp ~/Downloads/faostat-2022-trade-extractor/output/public/data/trade/*_2022.json public/data/trade/
npm run dev
```

3. Open `http://localhost:4173` (unless Vite prints another port).
4. Under Data Layers → Trade, toggle the four **2022 (FAOSTAT)** layers.
5. Turn **Rice Trade (Simulated)** OFF so old yellow animated dots disappear.

## Display

- Arc direction is exporter → importer, representing statistical trade, not a shipping route.
- Colored glowing arc shows a connection; flowing **chevron arrows lie on the arc**.
- More tonnes = thicker, brighter line and more arrows (1 to 6).
- Arrow count uses the same tonnes thresholds across all four crops.
- No detached moving yellow dots. Dataset and trade values are real; arrow animation is illustrative.
- FAOSTAT reported exports are preferred; mirrored importer reports are flagged by the source JSON.

## Validation

```bash
npm run check:boundaries
npm run build
```

The old simulated rice layer remains for comparison and is not deleted. Both
new JS files and two source edits are installed without overwriting divergent
user files; backups are saved in `.agri-trade-2022-backup/`.

The new four layers are `local-only` (not included in saved state/share links).
Source: FAOSTAT Detailed Trade Matrix, 2022. Only the **filtered** flows from
the user's JSON are mapped, so verify `actualCoveragePct` in each layer.

Current dataset summary (from user-provided terminal screenshot):

| crop | valid pair records | mapped routes | coverage of mapped trade tonnes |
|---|---:|---:|---:|
| Rice, milled | 3,815 | 120 | 82.335% |
| Wheat | 2,044 | 120 | 72.77% |
| Maize | 3,095 | 120 | 87.484% |
| Soybeans | 1,806 | 69 | 95.033% |

No full-browser or actual JSON integration test was possible here because the
user's local GEV checkout and four output datasets are on their Mac.
