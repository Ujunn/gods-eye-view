import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
const src=await fs.readFile(new URL('../src/ui/resilienceFollowCamera.js',import.meta.url),'utf8');
let releases=[];let holds=[];let events=[];let cameraMoves=[];
const Cesium={
 Math:{PI_OVER_TWO:Math.PI/2},
 SceneMode:{SCENE3D:3},
 Cartesian3:{ZERO:{},UNIT_X:{},fromDegrees:(lon,lat)=>({lon,lat}),fromRadians:(lon,lat,h)=>({lon,lat,h})},
 Cartographic:{fromDegrees:(lon,lat)=>({longitude:lon,latitude:lat})},
 BoundingSphere:class {constructor(center,radius){this.center=center;this.radius=radius;} static fromPoints(points){return new this(points[10],2e6);}},
 EllipsoidGeodesic:class {constructor(a,b){this.a=a;this.b=b;this.surfaceDistance=2e6;} interpolateUsingFraction(t){return {longitude:this.a.longitude+(this.b.longitude-this.a.longitude)*t,latitude:this.a.latitude+(this.b.latitude-this.a.latitude)*t};}},
 HeadingPitchRange:class {constructor(heading,pitch,range){this.heading=heading;this.pitch=pitch;this.range=range;}}
};
globalThis.Cesium=Cesium;
globalThis.holdContinuousRender=id=>holds.push(id);
globalThis.releaseContinuousRender=id=>releases.push(id);
globalThis.CustomEvent=class {constructor(type,init){this.type=type;this.detail=init.detail}};
globalThis.window={dispatchEvent:event=>{events.push(event.type);}};
let code=src.replace("import * as Cesium from 'cesium';",'const Cesium=globalThis.Cesium;').replace("import { holdContinuousRender, releaseContinuousRender } from '../renderGovernor.js';",'const {holdContinuousRender,releaseContinuousRender}=globalThis;');
const {createResilienceAttackFollow}=await import('data:text/javascript;base64,'+Buffer.from(code).toString('base64'));
const nodes=new Map([['A',{id:'A',name:'A国',lon:100,lat:20}],['B',{id:'B',name:'B国',lon:115,lat:5}],['C',{id:'C',name:'C国',lon:-90,lat:30}]]);
const edges=new Map([['AB',{id:'AB',source:'A',target:'B'}],['AC',{id:'AC',source:'A',target:'C'}]]);
let cancel=null;
const viewer={scene:{mode:3},isDestroyed:()=>false,camera:{
 flyToBoundingSphere(sphere,options){cameraMoves.push(sphere);cancel=options.cancel;viewer.camera.lastRange=options.offset.range;setTimeout(()=>{cancel=null;options.complete();},15);},
 cancelFlight(){cancel?.();cancel=null;},
}};
let attacks=[],ends=[];
const follow=createResilienceAttackFollow({viewer,getNode:id=>nodes.get(id),getEdge:id=>edges.get(id),onAttack:a=>attacks.push(a),onEnd:reason=>ends.push(reason)});
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function until(fn,max=700){const t=Date.now();while(!fn()){if(Date.now()-t>max)throw new Error('Timed out waiting for condition');await sleep(5);}}
// Node attack: one specific object, manual pause stops subsequent attacks.
follow.play({mode:'node-targeted',order:['A','B','C'],secondsPerTarget:2});
await until(()=>attacks.length===1);
assert.equal(attacks[0].id,'A');
assert.equal(attacks[0].index,1);
follow.stop('user');
await sleep(70);
assert.equal(attacks.length,1);
assert.equal(follow.isRunning(),false);
assert.equal(ends.at(-1),'user');
// Resume from the next target without replaying A; explicit mode and order remain intact.
follow.play({mode:'node-targeted',order:['A','B','C'],fromCount:1,secondsPerTarget:2});
await until(()=>attacks.length===2);
assert.equal(attacks[1].id,'B');
assert.equal(attacks[1].index,2);
follow.stop();
assert.equal(attacks.length,2);
// Edge target uses a bounding sphere built from the entire route.
follow.play({mode:'edge-targeted',order:['AB','AC'],secondsPerTarget:2});
await until(()=>attacks.length===3);
assert.equal(attacks[2].id,'AB');
assert.ok(cameraMoves.length>=3);
assert.equal(cameraMoves[0].radius,400_000); // Node target sphere
assert.equal(viewer.camera.lastRange,17_000_000);
follow.stop();
assert.equal(holds.length,releases.length);
assert.equal(events.filter(e=>e==='gev:earth-spin-suspend').length,events.filter(e=>e==='gev:earth-spin-resume').length);
console.log('[PASS] v7 wide-view target-by-target, pause, resume, edge flight, render/spin resource cleanup');
