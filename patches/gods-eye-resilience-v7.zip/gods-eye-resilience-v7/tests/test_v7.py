#!/usr/bin/env python3
"""Fast offline test: 4 independent data sets and complete attack sequences."""
import csv, json, subprocess, sys, tempfile
from pathlib import Path

here=Path(__file__).resolve().parents[1]
coords={
 '001':{'iso3':'AAA','lat':0,'lon':0,'name':'A'},
 '002':{'iso3':'BBB','lat':10,'lon':20,'name':'B'},
 '003':{'iso3':'CCC','lat':-10,'lon':-20,'name':'C'},
 '004':{'iso3':'DDD','lat':20,'lon':40,'name':'D'},
 '005':{'iso3':'EEE','lat':-20,'lon':-40,'name':'E'},
}
with tempfile.TemporaryDirectory() as temp:
 tmp=Path(temp); cp=tmp/'coords.json';cp.write_text(json.dumps(coords))
 for crop in ('rice','wheat','maize','soybeans'):
  inp=tmp/f'{crop}_full.csv';out=tmp/f'{crop}_2022_lab.json'
  with inp.open('w',newline='',encoding='utf-8') as file:
   writer=csv.DictWriter(file,fieldnames=['exporter_m49','importer_m49','exporter_name','importer_name','volume_tonnes']);writer.writeheader()
   pairs=[('001','002',120),('002','001',50),('001','003',60),('004','005',35),('002','003',15),('003','005',22)]
   for a,b,value in pairs:
    writer.writerow({'exporter_m49':a,'importer_m49':b,'exporter_name':coords[a]['name'],'importer_name':coords[b]['name'],'volume_tonnes':value})
  cp_run=subprocess.run([sys.executable,str(here/'scripts/resilience/prepare_multicrop.py'),'--input',str(inp),'--coords',str(cp),'--output',str(out),'--crop',crop],capture_output=True,text=True)
  if cp_run.returncode:raise AssertionError(cp_run.stderr)
  data=json.loads(out.read_text())
  assert data['meta']['crop']==crop and data['meta']['fullNetwork'] is True
  assert len(data['nodes'])==5 and len(data['edges'])==5
  assert any(x['dominantExportTonnes']==120 for x in data['edges'])
  for mode,exp in data['experiments'].items():
   assert len(exp['steps'])==101 and len(exp['order'])==(len(data['nodes']) if mode.startswith('node-') else len(data['edges']))
   assert len(set(exp['order']))==len(exp['order'])
   assert exp['steps'][0]['metrics']['efficiencyRetentionPct']==100
   assert exp['steps'][100]['metrics']['efficiencyRetentionPct']==0
   assert exp['steps'][100]['removedCount']==len(exp['order'])
  print(f'[OK] {crop}: all four strategies, complete bilateral topology and 101 score snapshots')
print('[PASS] v7 four-crop contract tests')
