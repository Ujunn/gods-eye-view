# God's Eye View · 韧性实验室 v7（四作物复现 + 宽视角跟拍）

**适用版本：** 已安装 v6「逐个目标攻击跟拍」的本地 `gods-eye-view`，分支 `agri-trade-2022`。

## v7 新功能

1. **镜头跟拍改为全球宽视角。** 节点飞行距离从 v6 约 590 万米增加至 1700 万米。边攻击飞行距离下限从 660 万米增至 1700 万米，尽量保持类似用户第二张截图那样能够看见整个地球的视野。最佳视角按钮仍然可用。
2. **在实验室顶部「研究作物」位置增加四个复选框**：🍚 水稻（精米）、🌾 小麦、🌽 玉米、🫘 大豆。默认只勾选大豆；可以同时勾选多种。各自使用青蓝／金黄／绿色／紫色的细实线，失效关系变为红线。
3. **独立仿真，统一攻击比例。** 每种作物各自使用对应的完整 FAOSTAT 2022 双边关系 CSV，计算 4 种攻击策略及六项网络指标。多选时，同步设置每种作物的攻击比例；**不是把多个作物合并成一个虚构网络**。
4. **主作物切换**：当勾选多种作物时，「主指标及镜头跟随作物」决定六项主指标和跟拍目标。其余勾选作物也在地球上呈现受攻击状态，面板以小型卡片显示各自网络效率保留率。跟拍时只跟随主作物，防止摄像机频繁跨作物跳转。
5. 保留 0～1% 步长细滑块（0.01% 精度）、0～100% 攻击程度滑块（0.01% 精度）、四种攻击策略、普通自动播放、逐对象跟拍（2～10秒）、暂停／恢复／重置、最佳视角。
6. 攻击对象切成红色**不再做沿线渐变**；只改变原贸易线材质，不叠加主路线红线，避免闪烁。前120条之外的受攻击关系仍最多另外标示18条／作物；原始网络计算始终使用全部关系。

## macOS 安装

下载并解压此 ZIP，把 `gods-eye-resilience-v7` 文件夹放进 `~/Downloads`，停止当前开发服务器，执行：

```bash
cd ~/Downloads/gods-eye-view
node ~/Downloads/gods-eye-resilience-v7/apply.mjs --check
bash ~/Downloads/gods-eye-resilience-v7/run_on_mac.sh
npm run build
npm run dev
```

`run_on_mac.sh` 默认使用此前的 FAOSTAT 提取结果：

- CSV 文件夹 `~/Downloads/faostat-2022-trade-extractor/output/cleaned/`，其中有 `rice_full.csv`, `wheat_full.csv`, `maize_full.csv`, `soybeans_full.csv`
- 国家坐标 `~/Downloads/faostat-2022-trade-extractor/country_centroids_m49.json`

如果你的提取目录不同，可以传入两个位置：

```bash
bash ~/Downloads/gods-eye-resilience-v7/run_on_mac.sh \
  '/你的路径/output/cleaned' \
  '/你的路径/country_centroids_m49.json'
```

脚本**仅对缺失的作物**运行 Python 预计算，不会重算、覆盖已有的大豆完整网络数据，也不会重新下载和扫描 400MB 原始 FAOSTAT 官方 ZIP。运行成功后新增：

- `public/data/resilience/rice_2022_lab.json`
- `public/data/resilience/wheat_2022_lab.json`
- `public/data/resilience/maize_2022_lab.json`

已有 `soybeans_2022_lab.json` 保留。生成过程每种作物要计算 4 种策略、各 101 个网络指标快照，在普通 Mac 上可能需要一段时间。

**如果缺少某一完整 CSV，脚本会明确报错并停止。不要用仅包含前 120 条关系的展示 JSON 代替它。**

安装脚本新增 `src/ui/resilienceMultiCrop.js`、`src/ui/resilienceFollowCamera.js`、`scripts/resilience/prepare_multicrop.py`，只修改 `src/main.js` 的接入。原来的 v5 `resilienceLab.js` 和 v6 `resilienceFollow.js` **不会被覆盖**，备份在 `.resilience-v7-backup/`。

## 复现和口径

- 使用 **FAOSTAT Detailed Trade Matrix 2022** 数据，水稻为 *Rice, milled*（精米），不是 UN Comtrade HS 1006 的全部大米定义。
- 每种作物单独建立**无向、无权拓扑**；贸易总量只用于边蓄意攻击排序；国家蓄意攻击按初始度排序，随机攻击固定种子。
- 所有节点或边均按各自初始数量的百分比移除，指标从该作物完整网络计算。
- 六项指标仍是 **整数百分比间隔（101个）**的预计算快照，面板会显示其对应比例；地图被攻击的对象数量可以以更细步长变化。跟拍每次一个真实节点或双边联系，但每次之后六项指标不一定变化。
- 被攻击的边只标记**结构失效**，不构成真实商品流改道证据。多选时并没有把不同作物合成一个网络。

## 离线测试

```bash
python3 ~/Downloads/gods-eye-resilience-v7/tests/test_v7.py
```

已执行代码语法、安装前检查、重复安装、四种作物独立生成和算法端点测试。**尚未在你的 Mac 上验证实际 Cesium 构图及镜头运动。**

## 推荐验收

1. 只选择大豆，进入节点蓄意攻击跟拍，看飞行距离是否接近你第二张截图的全局尺度。
2. 选择「大豆 + 小麦」，不勾跟拍，攻击 10%，检查紫色、黄色线路分别被红色标记，主指标切换正确。
3. 同时勾选四种作物，切换主作物到水稻，然后开启边随机攻击跟拍，检查镜头只跟随水稻，而其余作物的攻击程度同步增加。
4. 关闭实验室，确认原先手动打开的常规贸易层能恢复。
