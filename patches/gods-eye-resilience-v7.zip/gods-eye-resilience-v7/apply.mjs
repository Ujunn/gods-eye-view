#!/usr/bin/env node
// Installer for an already installed v6. Backups and an all-or-nothing write.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const cwd=process.cwd(),pkg=path.dirname(fileURLToPath(import.meta.url));
const check=process.argv.includes('--check');
function stop(message){throw new Error(`[STOP] ${message}；不会覆盖文件`);}
const dest=rel=>path.join(cwd,rel);
const get=rel=>fs.readFileSync(dest(rel),'utf8');
const payload=rel=>fs.readFileSync(path.join(pkg,rel),'utf8');
const oldMainMarker="import { installResilienceLab } from './ui/resilienceLab.js';";
const oldFollowMarker="import { installResilienceFollowUi } from './ui/resilienceFollow.js';";
const newMarker="import { installMultiCropResilience } from './ui/resilienceMultiCrop.js';";
function updateMain(s){
  if(s.includes(newMarker))return s;
  for(const token of [oldMainMarker,oldFollowMarker,
    'const cleanupLab = installResilienceLab({ viewer: scene.viewer, dataManager: data.dataManager });',
    'const cleanupFollow = installResilienceFollowUi({ viewer: scene.viewer });',
    'cleanupFollow();','cleanupLab();']){
    if(s.split(token).length!==2)stop(`src/main.js 未找到唯一的 v6 标志: ${token}`);
  }
  return s.replace(oldMainMarker,newMarker).replace(`${oldFollowMarker}\n`,'')
    .replace('const cleanupLab = installResilienceLab({ viewer: scene.viewer, dataManager: data.dataManager });',
      'const cleanupLab = installMultiCropResilience({ viewer: scene.viewer, dataManager: data.dataManager });')
    .replace(/^\s*const cleanupFollow = installResilienceFollowUi\(\{ viewer: scene.viewer \}\);\n/m,'')
    .replace(/^\s*cleanupFollow\(\);\n/m,'');
}
try{
  const meta=JSON.parse(get('package.json'));
  if(meta.name!=='gods-eye-view')stop('请先进入 gods-eye-view 项目根目录');
  if(!fs.existsSync(dest('src/ui/resilienceFollow.js'))||!fs.existsSync(dest('src/ui/resilienceLab.js')))
    stop('未发现已安装的 v6；请先安装 v6');
  const currMain=get('src/main.js'),newMain=updateMain(currMain);
  const paths=['src/ui/resilienceMultiCrop.js','src/ui/resilienceFollowCamera.js',
    'scripts/resilience/prepare_multicrop.py'];
  const changes=[{rel:'src/main.js',before:currMain,after:newMain}];
  for(const rel of paths){
    const content=payload(rel);
    const previous=fs.existsSync(dest(rel))?get(rel):null;
    if(previous!==null && previous!==content)stop(`${rel} 已存在自定义内容`);
    changes.push({rel,before:previous,after:content});
  }
  const todo=changes.filter(x=>x.before!==x.after);
  if(!todo.length){console.log('[OK] v7 已安装，无需重复安装');process.exit(0);}
  console.log('[v7] 即将更新:',todo.map(x=>x.rel).join(', '));
  console.log('[v7] 不会覆盖 v6 韧性源码、原始贸易 JSON 和已有四作物实验 JSON');
  if(check){console.log('[OK] 安装前检查通过（未写入）');process.exit(0);}
  const backup=dest('.resilience-v7-backup');
  for(const file of todo){
    if(file.before===null)continue;
    const target=path.join(backup,file.rel);fs.mkdirSync(path.dirname(target),{recursive:true});
    if(!fs.existsSync(target))fs.writeFileSync(target,file.before,{flag:'wx'});
  }
  const written=[];
  try{
    for(const file of todo){
      fs.mkdirSync(path.dirname(dest(file.rel)),{recursive:true});
      const temp=dest(file.rel)+'.v7tmp';fs.writeFileSync(temp,file.after);fs.renameSync(temp,dest(file.rel));
      written.push(file);console.log('[UPDATED]',file.rel);
    }
  }catch(error){
    for(const file of written.reverse()){
      if(file.before===null)fs.rmSync(dest(file.rel),{force:true});
      else fs.writeFileSync(dest(file.rel),file.before);
    }
    throw error;
  }
  console.log('[OK] v7 界面已安装。下一步运行 ./run_on_mac.sh 生成另外三种作物的完整网络攻击结果。');
  console.log('[BACKUP] .resilience-v7-backup');
}catch(error){console.error(error.message);process.exitCode=1;}
