#!/usr/bin/env bash
set -euo pipefail
ROOT="$(pwd)"
BUNDLE="$(cd "$(dirname "$0")" && pwd)"
SOURCE_DIR="${1:-$HOME/Downloads/faostat-2022-trade-extractor/output/cleaned}"
COORDS="${2:-$HOME/Downloads/faostat-2022-trade-extractor/country_centroids_m49.json}"
if [[ ! -f "$ROOT/package.json" ]] || ! grep -q '"name": "gods-eye-view"' "$ROOT/package.json"; then
  echo '错误：请先 cd ~/Downloads/gods-eye-view' >&2; exit 1
fi
if [[ ! -f "$COORDS" ]]; then echo "缺少国家坐标文件：$COORDS" >&2;exit 1;fi
for crop in rice wheat maize soybeans; do
  file="$SOURCE_DIR/${crop}_full.csv"
  output="$ROOT/public/data/resilience/${crop}_2022_lab.json"
  if [[ -f "$output" ]]; then
    echo "[KEEP] $crop 已有完整实验文件：$output"
    continue
  fi
  if [[ ! -s "$file" ]]; then
    echo "缺少 $file。不能使用前 120 条的 trade JSON 替代完整双边网络。" >&2
    exit 1
  fi
  echo "[CALCULATE] $crop (2022 FAOSTAT complete network)"
  python3 "$BUNDLE/scripts/resilience/prepare_multicrop.py" \
    --input "$file" --coords "$COORDS" --output "$output" --crop "$crop"
done
node "$BUNDLE/apply.mjs" --check
node "$BUNDLE/apply.mjs"
echo '[DONE] 接着执行 npm run build && npm run dev'
