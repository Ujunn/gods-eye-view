# God's Eye View · 韧性实验室 v5：红色贸易线闪烁修复

针对已安装 **v4** 的本地项目，**只修改 `src/ui/resilienceLab.js`**。不影响 FAOSTAT 数据、网络攻击算法、攻击步长、线宽、星空或相机环绕设置。

## 原因与修复

旧版每次攻击状态变化时使用 `effectsSource.entities.removeAll()` 清除前 120 条之外的红色贸易线，再用 `createEdge()` 重建最多 18 条。Cesium 需要重新提交这些折线的几何数据，播放中可能出现闪烁。

新版只创建最多 **18 个稳定的红色折线 Entity**：
- 同一贸易关系仍在展示时，不重新创建对象，也不更新它的几何位置。
- 新关系替换旧关系时，只更新复用槽位的几何位置与标签。
- 攻击退回时把对应槽位隐藏；再次攻击时复用原对象。
- 前 120 条主线继续使用原来的即时变红逻辑。

如果关闭环绕并停在固定攻击百分比后仍有闪烁，可能还存在像素抗锯齿或深度测试问题，需要进一步检查浏览器实测效果。

## 安装（Mac）

1. 下载并解压 ZIP 到 `~/Downloads/gods-eye-resilience-v5`。
2. 在运行 `npm run dev` 的终端按 `Control + C` 停止服务。
3. 在终端执行：

```bash
cd ~/Downloads/gods-eye-view
node ~/Downloads/gods-eye-resilience-v5/apply.mjs --check
node ~/Downloads/gods-eye-resilience-v5/apply.mjs
npm run build
npm run dev
```

4. 打开 http://localhost:4173 ，按 `Command + Shift + R` 强制刷新。

补丁安装前严格验证 `src/ui/resilienceLab.js` 为已知的 v4 版本。检测到手动修改就拒绝覆盖。原文件备份：

`~/Downloads/gods-eye-view/.resilience-v5-backup/src/ui/resilienceLab.js`

## 建议验证

1. 打开大豆韧性实验室，选择 **边随机攻击**。
2. 调节攻击程度到 15%，停止自动播放，关闭镜头环绕，检查红线是否稳定。
3. 从 15% 缓慢拉到 25%，检查红线是否频繁消失再出现。
4. 从 25% 退回 10%，再拉到 25%，检查已出现过的红线是否稳定。
5. 切换到节点蓄意攻击，检查红线和国家红色点是否正常。

## 测试与限制

已通过两种 v4 版本的 JavaScript 语法检查、固定 18 槽位测试、重复更新零几何写入测试、滑块回退复用测试，以及安装脚本版本校验/备份/重复执行测试。

尚未在你的本地 Cesium 浏览器场景中验收，因此这是针对已确认的实体反复重建问题的修复，不代表已经排除所有可能导致闪烁的渲染因素。

本次补丁不会自动推送至 GitHub。验证成功后，可仅提交 `src/ui/resilienceLab.js` 并推送到自己的开发分支。
