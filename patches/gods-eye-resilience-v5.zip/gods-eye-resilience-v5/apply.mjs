#!/usr/bin/env node
// v5, narrowly scoped flicker fix: stable pool of at most 18 extra red polylines.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const root=process.cwd();
const here=path.dirname(fileURLToPath(import.meta.url));
const checkOnly=process.argv.includes('--check');
const rel='src/ui/resilienceLab.js';
const previousVersions=[
  {label:'v4-on-v3',variant:'v3',hash:'c28c2a2c87eaff33fbc814991208890c959d3b99fdf53e1ef093129fc29acc82'},
  {label:'v4-on-v2',variant:'v2',hash:'a0f8708b49bc5f980a7b1d5d0c10f708dc8cad703bcaee116a8f20b9303ce1c0'},
];
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const stop=m=>{throw new Error(`[STOP] ${m}。没有覆盖任何项目文件。`)};
try {
  const manifest=path.join(root,'package.json');
  if(!fs.existsSync(manifest))stop('先进入 gods-eye-view 项目根目录');
  const pkg=JSON.parse(fs.readFileSync(manifest,'utf8'));
  if(pkg.name!=='gods-eye-view')stop('当前不是 gods-eye-view 项目');
  const target=path.join(root,rel);
  if(!fs.existsSync(target))stop(`找不到 ${rel}，请先安装 v4`);
  const current=fs.readFileSync(target);
  const currentHash=sha(current);
  const patches=previousVersions.map(entry=>{
    const next=fs.readFileSync(path.join(here,'src/ui',`resilienceLab.${entry.variant}.js`));
    return {...entry,next,nextHash:sha(next)};
  });
  const already=patches.find(p=>p.nextHash===currentHash);
  if(already){console.log('[OK] v5 红线防闪烁补丁已安装，无需重复修改。');process.exit(0);}
  const prior=patches.find(p=>p.hash===currentHash);
  if(!prior)stop(`本地 ${rel} 不是识别的 v4 标准文件 (SHA256 ${currentHash})；请不要强行覆盖手动改动`);
  console.log(`[OK] 检测到 ${prior.label}，将只更新 ${rel}`);
  if(checkOnly){console.log('[OK] 预检查通过；未修改项目文件。');process.exit(0);}
  const backup=path.join(root,'.resilience-v5-backup',rel);
  fs.mkdirSync(path.dirname(backup),{recursive:true});
  if(!fs.existsSync(backup))fs.writeFileSync(backup,current,{flag:'wx'});
  const temp=target+'.v5-tmp';
  try{fs.writeFileSync(temp,prior.next);fs.renameSync(temp,target);}catch(error){
    try{fs.rmSync(temp,{force:true});}catch{}
    throw error;
  }
  console.log('[UPDATED] 红色额外贸易线改为最多 18 个常驻复用的 Cesium Entity。');
  console.log('[OK] 保留原来的线宽、红色高亮、攻击步长、数据、相机与面板。');
  console.log(`[BACKUP] ${backup}`);
}catch(error){console.error(error.message);process.exitCode=1;}
