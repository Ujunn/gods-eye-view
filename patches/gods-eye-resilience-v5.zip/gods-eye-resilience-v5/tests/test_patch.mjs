import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
const dir=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const v4=path.join(path.dirname(dir),'gods-eye-resilience-v4');
const sha=data=>crypto.createHash('sha256').update(data).digest('hex');
const run=(cwd,opts=[])=>spawnSync(process.execPath,[path.join(dir,'apply.mjs'),...opts],{cwd,encoding:'utf8'});
for(const variant of ['v2','v3']){
  const old=fs.readFileSync(path.join(v4,'src/ui',`resilienceLab.${variant}.js`));
  const patch=fs.readFileSync(path.join(dir,'src/ui',`resilienceLab.${variant}.js`),'utf8');
  assert.doesNotMatch(patch,/effectsSource\.entities\.removeAll\(\)/);
  assert.match(patch,/syncExtraEdges\(damaged,isNode\)/);
  assert.match(patch,/EXTRA_LINE_LIMIT=18/);
  assert.match(patch,/id:extra\?`lab-extra-slot-\$\{slot\}`/);
  assert.match(patch,/slider\.step='0\.01'/);
  if(variant==='v3') assert.match(patch,/graphic\.entity\.polyline\.width=attacked\?3\.3:1\.8/);
  // White-box test the Cesium-independent slot sync algorithm with mock entities.
  const start=patch.indexOf('  function syncExtraEdges(damaged,isNode) {');
  const end=patch.indexOf('  function draw() {',start);
  assert.ok(start>0&&end>start);
  const code=patch.slice(start,end);
  let adds=0,positionUpdates=0;
  const edges=Array.from({length:30},(_,i)=>({id:`e${i}`,source:`n${i%5}`,target:`n${i%7+5}`,volumeTonnes:i+1}));
  const loaded={edges}, mainEdgeIds=new Set(edges.slice(0,3).map(e=>e.id));
  const extraGraphics=[];
  const nodeById=new Map(Array.from({length:12},(_,i)=>[`n${i}`,{id:`n${i}`,name:`Node ${i}`} ]));
  const arc=(a,b)=>[a.id,b.id];
  const createEdge=(edge,{extra,slot})=>{
    assert.equal(extra,true);
    const entity={show:true,name:edge.id,polyline:{}};
    Object.defineProperty(entity.polyline,'positions',{get(){return this._pos},set(v){this._pos=v;positionUpdates++}});
    entity.polyline.positions=[edge.source,edge.target];
    adds++;
    return {edge,entity,positions:entity.polyline.positions};
  };
  const sync=new Function('loaded','mainEdgeIds','extraGraphics','nodeById','createEdge','arc','EXTRA_LINE_LIMIT',code+'\nreturn syncExtraEdges;')(
    loaded,mainEdgeIds,extraGraphics,nodeById,createEdge,arc,18
  );
  const many=new Set(edges.map(e=>e.id));
  sync(many,false);assert.equal(adds,18);assert.equal(extraGraphics.length,18);
  const unchanged=positionUpdates;
  sync(many,false);assert.equal(adds,18);assert.equal(positionUpdates,unchanged,'same set must not change geometry');
  sync(new Set(),false);assert.ok(extraGraphics.every(x=>!x.entity.show));
  sync(many,false);assert.equal(adds,18);assert.equal(positionUpdates,unchanged,'drag-back should reuse geometry');
  sync(new Set([edges[29].id]),false);assert.equal(adds,18);assert.ok(positionUpdates>unchanged,'a different visible edge updates only changed slot');
  assert.equal(extraGraphics[0].edge.id,edges[29].id);
  assert.equal(extraGraphics.filter(x=>x.entity.show).length,1);
  const dirTemp=fs.mkdtempSync(path.join(os.tmpdir(),`gev-v5-${variant}-`));
  try{
    fs.writeFileSync(path.join(dirTemp,'package.json'),JSON.stringify({name:'gods-eye-view'}));
    fs.mkdirSync(path.join(dirTemp,'src/ui'),{recursive:true});
    const target=path.join(dirTemp,'src/ui/resilienceLab.js');fs.writeFileSync(target,old);
    const pre=run(dirTemp,['--check']);assert.equal(pre.status,0,pre.stderr);
    assert.equal(sha(fs.readFileSync(target)),sha(old));
    const installed=run(dirTemp);assert.equal(installed.status,0,installed.stderr);
    assert.equal(sha(fs.readFileSync(target)),sha(Buffer.from(patch)));
    assert.equal(sha(fs.readFileSync(path.join(dirTemp,'.resilience-v5-backup/src/ui/resilienceLab.js'))),sha(old));
    assert.equal(run(dirTemp).status,0,'idempotence');
    fs.appendFileSync(target,'\n// local patch');
    const changed=sha(fs.readFileSync(target));
    assert.notEqual(run(dirTemp).status,0,'reject unknown content');
    assert.equal(sha(fs.readFileSync(target)),changed,'no overwrite of local code');
  }finally{fs.rmSync(dirTemp,{recursive:true,force:true});}
  console.log(`${variant}: 18 stable slots, no redundant geometry rewrites, backtracking, guard and backups PASS`);
}
