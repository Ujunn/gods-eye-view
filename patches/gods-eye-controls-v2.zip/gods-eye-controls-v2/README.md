# God's Eye View · 自转速度 + 四作物贸易线路控制（v2）

本补丁是**增量更新**，要求先前两个安装包已成功接入：

- `gods-eye-earth-spin`（有右下角地球自转开关）
- `gods-eye-agri-trade-2022`（有四种 FAOSTAT 2022 真实贸易流图层）

本补丁**不会覆盖** `src/main.js`、`src/app/constructCatalog.js`、四份 JSON，也不读取或上传任何密钥。它会检查前两版源文件的 SHA-256；如发现你已经手工修改过，就**停止覆盖并提示**，防止丢失代码。

## 安装步骤（macOS）

1. 将 ZIP 解压得到 `gods-eye-controls-v2`，放在 Mac 的下载目录。
2. 如果项目还在 `npm run dev`，终端按 `Control+C`。
3. 在终端执行：

```bash
cd ~/Downloads/gods-eye-view
node ~/Downloads/gods-eye-controls-v2/apply.mjs
npm run build
npm run dev
```

4. 浏览器访问 `http://localhost:4173`（以 Vite 实际输出为准），按 `Command+Shift+R` 强制刷新。

## 交互

### 自转速度

右下角「地球自转 ON/OFF」旁有 `⚙` 设置按钮，点击展开二级滑块。

- 控制**自转周期（秒/圈）**：`5—120` 秒，步长 `5` 秒。
- 默认 `30 秒/圈`；拉到左侧更快，右侧更慢。
- 通过浏览器 localStorage 保存；刷新保持上次设定。
- 鼠标拖拽暂停自转；松开约 250ms 后继续，不会回到旧视角。
- 仅进行摄像机绕地轴视觉模拟，不改变地理坐标与贸易网络。

### 贸易线路数量

在 Data Layers → Trade，四个真实数据图层的每行按钮下方显示「显示贸易线路」滑块。

- 每种作物**独立**调节 `0—当前 JSON 可用线路数`，步长 1。
- 默认每种 30 条，四种同时开启大约展示 120 条线。
- 按真实的 `volumeTonnes` 降序排名，保留前 N 条。滑块变小时隐藏小线路，变大时恢复，不重读 JSON、无重算数据。
- 原 JSON 各自最多 120 条；大豆实际只有 69 条。**不能把滑块调到原始 CSV 里、却未导出到 JSON 的线路**。想扩充上限必须重新从原始数据生成 JSON。
- 调节不修改真实贸易量、贸易方向或箭头数量规则；已显示线路的动态箭头保留。
- 关闭图层时当前线路数设置保留；刷新页面后线路数恢复默认 30（自转周期会记忆）。

图层运行期间不会重复创建实体：首次读取 JSON 后建立 Cesium 贸易弧线与箭头，滑块仅切换 `show`，比重新渲染整批数据更平稳。

## 出错及恢复

如 `apply.mjs` 输出 STOP，**不要继续 `npm run build`**。先检查是否安装了前两版包；若是你手动改过自定义模块，请保留本机修改并联系我做差异兼容。

安装前备份在：`.trade-controls-v2-backup/`。

如果需要撤销本次更新，请确认备份存在且项目目录没有新的更改：

```bash
cd ~/Downloads/gods-eye-view
cp .trade-controls-v2-backup/src/ui/earthSpin.js src/ui/earthSpin.js
cp .trade-controls-v2-backup/src/layers/agriTrade/index.js src/layers/agriTrade/index.js
cp .trade-controls-v2-backup/src/ui/layerPanel.js src/ui/layerPanel.js
rm -f src/ui/tradeRouteSlider.js
```

不要恢复更早的 `.earth-spin-backup/src/main.js`，避免清掉后来接入的功能。

## 检查

```bash
node --check src/ui/earthSpin.js
node --check src/ui/tradeRouteSlider.js
node --check src/layers/agriTrade/index.js
node --check src/ui/layerPanel.js
npm run check:boundaries
npm run build
```

此次补丁完成了文件语法与安装流程测试；尚未在你的本机完整 God's Eye View + 2022 原始 JSON 中做浏览器验收。

## 汉化可行性

可行。未来建议用 `zh-CN/en-US` 文案字典逐步改造 `src/ui`、HTML 模板、HUD、各个 layer 的 `name`/`info`，以及提示与设置项。不要全局直接替换英文原始代码；英文 API 参数、数据源名称和坐标字段保持不变。此包**不包含汉化**。
