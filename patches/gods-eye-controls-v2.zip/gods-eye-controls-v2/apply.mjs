#!/usr/bin/env node
/** Upgrade already-installed Earth Spin + four FAOSTAT crop layers with sliders.
 * Never touches JSON, package dependencies, original main.js wiring or secrets.
 * Requires the exact previous versions of the two custom modules; refuse to
 * overwrite any user-modified modules.
 */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const root = process.cwd();
const patch = path.dirname(fileURLToPath(import.meta.url));
const names = {
  spin: 'src/ui/earthSpin.js',
  agri: 'src/layers/agriTrade/index.js',
  panel: 'src/ui/layerPanel.js',
  slider: 'src/ui/tradeRouteSlider.js',
};
const previous = {
  spin: '5eb20e760613303ace539ae4263b53ef724cb28e2ff7bef5824f69f6837b49e1',
  agri: '7ca2b47801adf85d0c768d50aaa6bb2dbc3e0c6b3b8bec6c54a7eea5f2256e8f',
};
const absolute = (name) => path.join(root, names[name]);
const patched = (name) => path.join(patch, names[name]);
const hash = (data) => crypto.createHash('sha256').update(data).digest('hex');
const error = (msg) => { throw Error(`[STOP] ${msg}. 未修改项目文件。`); };
const requireFile = (p) => { if (!fs.existsSync(p)) error(`找不到文件 ${p}`); return fs.readFileSync(p); };

function afterOnce(input, anchor, additional) {
  const idx = input.indexOf(anchor);
  if (idx < 0 || input.indexOf(anchor, idx + anchor.length) !== -1)
    error(`无法唯一定位主项目面板代码：${anchor.trim()}`);
  return input.slice(0, idx + anchor.length) + additional + input.slice(idx + anchor.length);
}

function buildPanel(text) {
  const importLine = "import { createTradeRouteSlider, syncTradeRouteSlider } from './tradeRouteSlider.js';";
  if (text.includes(importLine)) {
    if (!text.includes('const routeSliderDescriptor = this._rowControlsFor(layer.id)?.range;') ||
        !text.includes('syncTradeRouteSlider(tradeSlider,'))
      error('layerPanel.js 已部分安装，请检查代码，不自动覆盖');
    return text;
  }
  let result = afterOnce(text, "import { syncChipGroup } from './chipGroup.js';",
    `\n${importLine}`);
  result = afterOnce(result, '      row.appendChild(bottomRow);', `

      // Second-level range for the four FAOSTAT trade layers only.
      const routeSliderDescriptor = this._rowControlsFor(layer.id)?.range;
      if (routeSliderDescriptor) {
        row.appendChild(createTradeRouteSlider(
          routeSliderDescriptor,
          (element, type, fn) => this._bind(element, type, fn),
          (value, key) => this.setLayerParams(layer.id, { [key]: value }, { origin: 'user' }),
        ));
      }`);
  result = afterOnce(result, '      const meta = row.querySelector(\'.data-toggle-meta\');\n      if (meta) {\n        meta.textContent = this._buildMetaText(layer);\n      }', `

      const tradeSlider = row.querySelector('.gev-trade-route-slider');
      if (tradeSlider) {
        syncTradeRouteSlider(tradeSlider, this._rowControlsFor(layer.id)?.range);
      }`);
  return result;
}

function main() {
  const pkg = JSON.parse(requireFile(path.join(root, 'package.json')));
  if (pkg.name !== 'gods-eye-view') error('请 cd ~/Downloads/gods-eye-view 后再安装');
  const main = requireFile(path.join(root, 'src/main.js')).toString();
  const catalog = requireFile(path.join(root, 'src/app/constructCatalog.js')).toString();
  if (!main.includes('installEarthSpin') || !catalog.includes('createApplicationAgriTrade'))
    error('需先安装之前的地球自转包和四农产品图层包');
  const existing = {};
  const pending = {};
  for (const key of ['spin','agri']) {
    existing[key] = requireFile(absolute(key));
    pending[key] = requireFile(patched(key));
    if (!existing[key].equals(pending[key]) && hash(existing[key]) !== previous[key])
      error(`${names[key]} 已被你修改过，为保护修改停止升级`);
  }
  existing.panel = requireFile(absolute('panel'));
  pending.panel = Buffer.from(buildPanel(existing.panel.toString()));
  pending.slider = requireFile(patched('slider'));
  if (fs.existsSync(absolute('slider'))) {
    existing.slider = requireFile(absolute('slider'));
    if (!existing.slider.equals(pending.slider)) error(`${names.slider} 已有自定义修改`);
  }

  const changes = Object.keys(pending).filter((key) => !existing[key]?.equals(pending[key]));
  if (!changes.length) {
    console.log('[OK] 两种滑块已安装；无需重复修改。');
    return;
  }
  const backup = path.join(root, '.trade-controls-v2-backup');
  // Save exact old content on first installation; never overwrite backups.
  for (const key of changes) {
    if (!existing[key]) continue;
    const target = path.join(backup, names[key]);
    fs.mkdirSync(path.dirname(target), { recursive: true });
    if (!fs.existsSync(target)) fs.writeFileSync(target, existing[key]);
  }
  for (const key of changes) {
    const dest = absolute(key);
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    const temp = `${dest}.rice-control-patch-tmp`;
    fs.writeFileSync(temp, pending[key]);
    fs.renameSync(temp, dest);
    console.log('[UPDATED]', names[key]);
  }
  console.log('\n[OK] 自转速度滑块 + 四种作物 top-N 线路滑块安装完成。');
  console.log('保留现有 FAOSTAT JSON，不会重新提取、联网或覆盖贸易数据。');
  console.log('下一步：npm run build && npm run dev');
}
try { main(); }
catch (err) { console.error(err.message); process.exitCode = 1; }
