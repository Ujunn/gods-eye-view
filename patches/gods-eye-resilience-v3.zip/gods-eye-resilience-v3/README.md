# God's Eye View · Resilience Lab v3（精简视觉补丁）

用于已安装 **v2** 的项目，不是一个全新版本。以 `Ujunn/gods-eye-view` 的 `agri-trade-2022` 分支加本地已安装的 v2 韧性实验室为基础。

## 改动

1. **恢复第一版线宽，保留实线**：四种作物使用最初的 `1.0 + 3.1 * sqrt(贸易量/最大贸易量)` px。没有虚线和白色光晕。韧性实验室存活线路恢复 **1.8px**，失效线路恢复第一版的 **3.3px**；保留原作物颜色和攻击红色。
2. **取消渐变染红**：不再创建叠加的第二条红线，也不再做沿方向推进的动画。攻击程度发生变化时，相关边立即整体变红；把滑块往回拉，立即恢复紫色。实际攻击顺序及韧性指标不变。
3. **镜头环绕重排**：移动到右上角、韧性实验室**上方且偏左**，贴合截图的红圈位置。只显示一个紧凑的“镜头环绕 ON/OFF”开关，点击旁边的 ⚙ 后，速度设置**向左展开成浮层**，不会遮盖右侧韧性面板。点击空白处、按 Esc 可收起设置。小屏幕采用上下排版。

不改变实验算法、FAOSTAT 数据、最小滑块步长、六项指标、摄影机围绕地球 Z 轴的旋转方式、鼠标拖拽后的继续旋转，以及实验室的“最佳视角”按钮。

## Mac 安装

1. 下载 `gods-eye-resilience-v3.zip` 后**解压**到 `~/Downloads/gods-eye-resilience-v3`。
2. 关闭正在运行的 `npm run dev`（终端按 **Control+C**）。
3. 在终端执行：

```bash
cd ~/Downloads/gods-eye-view
node ~/Downloads/gods-eye-resilience-v3/apply.mjs --check
node ~/Downloads/gods-eye-resilience-v3/apply.mjs
npm run build
npm run dev
```

打开 <http://localhost:4173>，按 `Command+Shift+R` 强制刷新。

检查内容：打开大豆韧性实验室，紫色线应更细；把攻击滑块推至 >0 时，被攻击线路应直接变为红色，往回拖恢复紫色；右上角镜头环绕开关和向左展开的 ⚙ 速度设置不遮挡实验室面板。其他三个农产品图层也应恢复原先细线宽度。

### 注意事项

- 脚本按 SHA-256 校验 v2 的 **3 个源文件**。如果你在安装 v2 后又手动修改这些文件，脚本会 `[STOP]`，**不会覆盖**。
- 安装时源文件备份在 `.resilience-v3-backup/`，**不要提交该备份目录到 GitHub**。
- `public/data/trade/*.json`、`public/data/resilience/soybeans_2022_lab.json` 均保持原样；无需重做 FAOSTAT 提取及 Python 仿真。
- 本包已进行静态语法与安装脚本验证，但没有在用户 Mac 上进行 Cesium 浏览器验收。

## GitHub（确认本地运行正确后）

```bash
cd ~/Downloads/gods-eye-view
git status --short
git add src/ui/earthSpin.js src/ui/resilienceLab.js src/layers/agriTrade/index.js
git diff --cached --stat
git commit -m "style: simplify trade lines and resilience controls"
git push ujunn agri-trade-2022
```

如果之前的 v2 还没有提交，上面这三个文件将连同 v2 的变更一起提交；其它未跟踪文件仍需单独检查并有选择地 `git add`。**不要执行 `git add .`**，以免提交备份、大数据或密钥。
