#!/usr/bin/env node
// Offline, hash-guarded v3 patch for the already-installed v2 modules.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const repo = process.cwd();
const bundle = path.dirname(fileURLToPath(import.meta.url));
const checkOnly = process.argv.includes('--check');
const files = [
  { path: 'src/ui/earthSpin.js',
    previous: 'ba78ff61cdd1a2e748f2623afa9ff6c9cdac7bea46ec33121655dda725618fb9' },
  { path: 'src/ui/resilienceLab.js',
    previous: '7b2ad63781c84b17fb9101eb476eabaec35556fa74ccbf86fca7797371a5e07c' },
  { path: 'src/layers/agriTrade/index.js',
    previous: '94ca63fee865fba91330c2a3e8da712f82a6065ae59aecebbad95761fd94dc70' },
];
const sha = (data) => crypto.createHash('sha256').update(data).digest('hex');
function fail(message) {
  throw new Error(`[STOP] ${message}。未覆盖任何源码，请保留你的本地修改。`);
}
function read(file) {
  if (!fs.existsSync(file)) fail(`找不到 ${file}`);
  return fs.readFileSync(file);
}
try {
  const pkg = JSON.parse(read(path.join(repo, 'package.json')).toString());
  if (pkg.name !== 'gods-eye-view') fail('请先 cd 进入 gods-eye-view 目录');
  const main = read(path.join(repo, 'src/main.js')).toString();
  if (!main.includes('installResilienceLab') || !main.includes('installEarthSpin'))
    fail('请先安装韧性实验室和镜头环绕功能');

  // Validate every source hash BEFORE writing anything. A user-edited local
  // project is never silently overwritten, and a partially applied patch
  // from a previous run can complete safely.
  const updates = [];
  for (const f of files) {
    const current = read(path.join(repo, f.path));
    const next = read(path.join(bundle, f.path));
    const currentHash = sha(current), nextHash = sha(next);
    if (currentHash === nextHash) continue;
    if (currentHash !== f.previous)
      fail(`${f.path} 与 v2 版本不一致，当前 SHA256 为 ${currentHash}`);
    updates.push({ ...f, current, next });
  }

  if (!updates.length) {
    console.log('[OK] v3 已安装。无需重复操作。');
    process.exit(0);
  }
  if (checkOnly) {
    console.log('[OK] v2 源码版本匹配，待修改文件：');
    updates.forEach((f) => console.log('  ', f.path));
    process.exit(0);
  }

  const backupDir = path.join(repo, '.resilience-v3-backup');
  for (const f of updates) {
    const dest = path.join(backupDir, f.path);
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    if (!fs.existsSync(dest)) fs.writeFileSync(dest, f.current, { flag: 'wx' });
  }
  for (const f of updates) {
    const dest = path.join(repo, f.path);
    const tmp = `${dest}.v3-tmp`;
    fs.writeFileSync(tmp, f.next);
    fs.renameSync(tmp, dest);
    console.log('[UPDATED]', f.path);
  }
  console.log('[OK] v3 完成：细实线、即时红色攻击、右上角镜头环绕及左侧展开设置。');
  console.log('未修改任何 FAOSTAT CSV、四作物 JSON 或韧性实验 JSON。');
} catch (error) {
  console.error(error.message);
  process.exitCode = 1;
}
