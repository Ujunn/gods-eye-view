#!/usr/bin/env node
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const v2 = path.resolve(root, '../gods-eye-resilience-v2');
const paths = ['src/ui/earthSpin.js', 'src/ui/resilienceLab.js', 'src/layers/agriTrade/index.js'];
const lab = fs.readFileSync(path.join(root, paths[1]), 'utf8');
const agri = fs.readFileSync(path.join(root, paths[2]), 'utf8');
const orbit = fs.readFileSync(path.join(root, paths[0]), 'utf8');
const sha = (b) => crypto.createHash('sha256').update(b).digest('hex');

assert.match(agri, /width: 1\.0 \+ 3\.1 \* strength/);
assert.match(agri, /new Cesium\.ColorMaterialProperty/);
assert.doesNotMatch(agri, /new Cesium\.PolylineGlowMaterialProperty/);
assert.match(lab, /const width=1\.8/);
assert.match(lab, /graphic\.entity\.polyline\.material=attacked\?FAILED_MATERIAL:ACTIVE_MATERIAL/);
assert.match(lab, /graphic\.entity\.polyline\.width=attacked\?3\.3:1\.8/);
for(const token of ['DAMAGE_OWNER','damagedAnimations','lab-attack-overlay','finishDamageTransitions'])
  assert.ok(!lab.includes(token), `unwanted damage transition: ${token}`);
assert.match(orbit, /top: 24px; right: 140px/);
assert.match(orbit, /right: calc\(100% \+ 10px\)/);
assert.match(orbit, /#gev-earth-spin-settings\[hidden\]/);
assert.doesNotMatch(orbit, /bottom:90px/);
assert.match(orbit, /style\.remove\(\)/);

if(!fs.existsSync(v2)) { console.log('Static UI checks passed (v2 fixture not present)'); process.exit(0); }
const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'gev-v3-test-'));
function command(args){return spawnSync(process.execPath, [path.join(root,'apply.mjs'),...args],{cwd:temp,encoding:'utf8'});}
function file(name){return path.join(temp,name);}
try {
  fs.writeFileSync(file('package.json'), JSON.stringify({name:'gods-eye-view'}));
  fs.mkdirSync(file('src'),{recursive:true});
  fs.writeFileSync(file('src/main.js'),'installResilienceLab(); installEarthSpin();');
  for (const p of paths) {
    fs.mkdirSync(path.dirname(file(p)),{recursive:true});
    fs.copyFileSync(path.join(v2,p),file(p));
  }
  assert.equal(command(['--check']).status,0,'preflight');
  const first = command([]);assert.equal(first.status,0,first.stderr);
  for(const p of paths){
    assert.equal(sha(fs.readFileSync(file(p))),sha(fs.readFileSync(path.join(root,p))));
    assert.equal(sha(fs.readFileSync(file('.resilience-v3-backup/'+p))),sha(fs.readFileSync(path.join(v2,p))));
  }
  assert.equal(command([]).status,0,'idempotence');
  // Modifying one source must prevent updating any of the other two.
  fs.copyFileSync(path.join(v2,paths[0]),file(paths[0]));
  fs.appendFileSync(file(paths[1]),'\n// user edit');
  const firstHash=sha(fs.readFileSync(file(paths[0])));
  const safety=command([]);assert.notEqual(safety.status,0,'tamper guard');
  assert.equal(sha(fs.readFileSync(file(paths[0]))),firstHash,'no partial writes');
  console.log('v3 checks passed: thin solid lines, instant red, anchored popover, hash guard, backups and idempotence.');
}finally{fs.rmSync(temp,{recursive:true,force:true});}
