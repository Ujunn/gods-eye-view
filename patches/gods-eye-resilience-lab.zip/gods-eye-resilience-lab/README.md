# God's Eye View：2022 大豆网络韧性实验室（第一阶段）

本包专门适配已完成的 `Ujunn/gods-eye-view` 的 `agri-trade-2022` 分支。
不会修改你现有的四个农产品贸易数据，也不会上传到 GitHub。

**交付：** 用 2022 年完整的 `soybeans_full.csv` 构造双边网络，预计算 4 种攻击模式（节点蓄意、节点随机、边蓄意、边随机）下 0–100% 的六项指标；新增右侧独立控制面板，支持攻击百分比滑块、播放／暂停／重置、红色失效标注和高亮显示网络效率保留率。关闭实验室后恢复先前启用的大豆图层。

## Mac 一键安装

你之前运行过 FAOSTAT 提取器，因此**不用再扫描 5200 万行原始数据，更不用重新下载 ZIP**。需要使用提取器已生成的完整大豆 CSV：

`~/Downloads/faostat-2022-trade-extractor/output/cleaned/soybeans_full.csv`

以及国家坐标表：

`~/Downloads/faostat-2022-trade-extractor/country_centroids_m49.json`

1. 解压本 ZIP 到「下载」，确保目录 `~/Downloads/gods-eye-resilience-lab` 存在。
2. 停止旧的 `npm run dev`（终端 `Control+C`）。
3. 执行：

```bash
cd ~/Downloads/gods-eye-view
git switch agri-trade-2022
bash ~/Downloads/gods-eye-resilience-lab/run_on_mac.sh
npm run dev
```

脚本会：检查本地 CSV → 用 Python 标准库预计算 4 套实验结果 → 输出 `public/data/resilience/soybeans_2022_lab.json` → 在 `src/main.js` 注册 UI 控件并复制 `src/ui/resilienceLab.js` → 运行算法单元测试和 `npm run build`。

浏览器打开 `http://localhost:4173`，页面**右上角**出现 `NETWORK RESILIENCE LAB`，点击后选择攻击方式并拖动滑块。

### 如果找不到 `soybeans_full.csv`

在 Finder 查找这个文件，或者终端执行：

```bash
find ~/Downloads -name soybeans_full.csv -print
```

若路径不同，直接传给脚本作为第一参数：

```bash
bash ~/Downloads/gods-eye-resilience-lab/run_on_mac.sh "/实际路径/soybeans_full.csv"
```

第二参数可指定国家坐标 JSON 的路径。

### 手动计算 / 重计算（修改随机种子）

```bash
cd ~/Downloads/gods-eye-view
python3 ~/Downloads/gods-eye-resilience-lab/prepare.py \
  --input ~/Downloads/faostat-2022-trade-extractor/output/cleaned/soybeans_full.csv \
  --coords ~/Downloads/faostat-2022-trade-extractor/country_centroids_m49.json \
  --output public/data/resilience/soybeans_2022_lab.json \
  --seed 20261015
```

修改 `--seed` 会生成新的随机攻击序列，蓄意攻击序列不变。

## 界面行为

- 选择攻击模式；滑块 0–100%，步长 1%。
- 主指标：**结构韧性 = 当前网络效率 / 未攻击网络效率 ×100%**，在旁边实时更新。
- 六个指标：平均聚类系数、平均度、网络效率、平均路径长度、最大连通子图占比、孤立节点占比。
- 被删除的**节点变红**；与已删除节点相连的线路及被直接删除的**边变红**，但在后台计算中已移除。
- 紫色为未失效的展示线路；幸存主要联系上继续显示少量运动箭头。攻击边超过可视化的前 120 条时，另以红色补充展示最多 18 条。
- 打开实验室时，若原有大豆贸易图层已经启用，则先停用该图层；关闭实验室后恢复，避免已失效线路继续播放旧的紫色箭头。
- 保持其他三种作物图层不变；演示时推荐手动关闭其他作物，减少重叠。

## 数据和论文方法的边界

**重要：这是攻击方法复现的第一阶段，不是原论文数字的严格重复。**

1. 当前数据是 FAOSTAT 2022 双边大豆贸易（包括缺报的进口镜像补充），而原论文使用 UN Comtrade HS 1201；商品范围和缺报处理不完全相同。
2. 以**国家为节点、双边贸易关系为无向边**。原始双向贸易金额按出口重量求和成为一条双边边权。这样才能与论文描述的“贸易联系”“节点度中心性”和“边权降序攻击”对齐，但仍需在严格复现阶段核实原作者的无向／有向处理细节。
3. 蓄意节点按**初始**无权度数降序固定排序；蓄意边按**初始**双边贸易量降序固定排序。相同排名按国家代码/关系 ID 决定顺序。随机攻击固定种子，当前只跑一条攻击路径，尚无重复试验的置信区间。
4. 攻击的百分比指删除**节点数或双边边数**所占初始数量，不是删除的贸易量占比；每步 `floor(N × p / 100)`。
5. 网络效率用无权、无向图的最短路径逆距离求和，除以**最初**节点数 `n(n-1)`；失败节点与其他节点不可达，效率为 0。这样效率保留率可以直接比较各攻击比例。
6. 其他部分指标也采用**固定初始 N** 的统计口径，删除的节点按零度／孤立处理；最大连通子图除以初始 N。**平均路径长度只对仍然可达的节点对计算**，网络碎裂时不一定单调增长。由于论文公式和实现细节存在一些未澄清处，当前只能称为“论文风格”的可审计实现。
7. 不做贸易量重分配，也不声称改变路线是实际发生的。图上红线是受攻击的**贸易关系**，不是实际航运路径。

### 输出文件

- `public/data/resilience/soybeans_2022_lab.json`：国家信息、完整贸易关系、4 种策略的排序、101 个攻击步长的六项指标。
- `src/ui/resilienceLab.js`：可视化组件，无须额外 npm 包。
- `src/main.js`：自动接入和资源销毁。

## 测试与 GitHub

本包已经做了 Python 合成网络单元测试、`node --check` 和安装脚本的隔离测试，但**没有在你的本地 Vite/Cesium 环境里做实际浏览器验收**。运行时出现构建错误，请把完整报错发回来。

验证无误后保存到 `Ujunn`：

```bash
cd ~/Downloads/gods-eye-view
git status --short
git add src/main.js src/ui/resilienceLab.js public/data/resilience/soybeans_2022_lab.json
git diff --cached --stat
git commit -m "feat: add soybean resilience attack lab"
git push
```

不要使用 `git add .`，以免误上传 `.resilience-lab-backup/` 等备份目录。
