#!/usr/bin/env node
/** Conservative installer for the Ujunn/agri-trade-2022 branch. */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const repo = process.cwd();
const base=path.dirname(fileURLToPath(import.meta.url));
const entry=path.join(repo,'src/main.js');
const moduleTarget=path.join(repo,'src/ui/resilienceLab.js');
const moduleSource=path.join(base,'src/ui/resilienceLab.js');
function stop(why){throw new Error(`[STOP] ${why}，没有修改你的项目。`);}
try {
  const pkg=JSON.parse(fs.readFileSync(path.join(repo,'package.json'),'utf8'));
  if(pkg.name!=='gods-eye-view')stop('请先 cd ~/Downloads/gods-eye-view');
  if(!fs.existsSync(entry)||!fs.existsSync(moduleSource))stop('缺少安装文件');
  let main=fs.readFileSync(entry,'utf8');
  const newModule=fs.readFileSync(moduleSource,'utf8');
  if(main.includes("installResilienceLab")) {
    if(fs.existsSync(moduleTarget)&&fs.readFileSync(moduleTarget,'utf8')===newModule) {
      console.log('[OK] 已安装韧性实验室；未重复修改');process.exit(0);
    }
    stop('发现其他韧性实验室版本，请先检查本地修改');
  }
  if(fs.existsSync(moduleTarget))stop('src/ui/resilienceLab.js 已存在，避免覆盖');
  const oldImport="import { installEarthSpin } from './ui/earthSpin.js';";
  const oldInit="  const cleanupSpin = installEarthSpin(scene.viewer);";
  const oldDestroy="      cleanupSpin();";
  for(const anchor of [oldImport,oldInit,oldDestroy]) {
    if(main.split(anchor).length!==2)stop(`无法唯一定位原有代码: ${anchor}`);
  }
  // The app's start payload has {scene, data}; data.dataManager owns layer visibility.
  if(!main.includes('application.start().then(({ scene }) => {'))stop('无法定位启动回调结构');
  main=main.replace(oldImport,oldImport+"\nimport { installResilienceLab } from './ui/resilienceLab.js';");
  main=main.replace('application.start().then(({ scene }) => {','application.start().then(({ scene, data }) => {');
  main=main.replace(oldInit,oldInit+"\n  const cleanupLab = installResilienceLab({ viewer: scene.viewer, dataManager: data.dataManager });");
  main=main.replace(oldDestroy,oldDestroy+"\n      cleanupLab();");
  const backup=path.join(repo,'.resilience-lab-backup','src/main.js');
  fs.mkdirSync(path.dirname(backup),{recursive:true});
  if(!fs.existsSync(backup))fs.copyFileSync(entry,backup);
  fs.mkdirSync(path.dirname(moduleTarget),{recursive:true});
  fs.writeFileSync(moduleTarget,newModule,'utf8');
  fs.writeFileSync(entry,main,'utf8');
  console.log('[OK] 已添加 Resilience Lab 按钮和前端模块');
  console.log('提醒：还需要先生成 public/data/resilience/soybeans_2022_lab.json');
}catch(e){console.error(e.message);process.exitCode=1;}
