#!/bin/bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
WORK="$HOME/Downloads/faostat-2022-trade-extractor"
REPO="$HOME/Downloads/gods-eye-view"
INPUT="${1:-$WORK/output/cleaned/soybeans_full.csv}"
COORDS="${2:-$WORK/country_centroids_m49.json}"
if [[ ! -f "$INPUT" ]]; then echo "[STOP] 找不到完整数据: $INPUT" >&2; exit 1; fi
if [[ ! -f "$COORDS" ]]; then echo "[STOP] 找不到国家坐标: $COORDS" >&2; exit 1; fi
if [[ ! -f "$REPO/package.json" ]]; then echo "[STOP] 找不到项目: $REPO" >&2; exit 1; fi
cd "$REPO"
python3 "$HERE/prepare.py" \
  --input "$INPUT" \
  --coords "$COORDS" \
  --output "$REPO/public/data/resilience/soybeans_2022_lab.json"
node "$HERE/apply.mjs"
python3 "$HERE/tests/test_prepare.py"
npm run build
printf '\n[OK] 数据已计算、前端已安装、构建完成。启动：cd %s && npm run dev\n' "$REPO"
