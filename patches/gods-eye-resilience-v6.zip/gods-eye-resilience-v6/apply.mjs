#!/usr/bin/env node
/** Add the cinematic attack-follow UI to an already-installed v5 lab.
 * This does NOT overwrite resilienceLab.js, simulations, or FAOSTAT data.
 */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const root=process.cwd();
const bundle=path.dirname(fileURLToPath(import.meta.url));
const checkOnly=process.argv.includes('--check');
const hash=s=>crypto.createHash('sha256').update(s).digest('hex');
const stop=msg=>{throw new Error(`[STOP] ${msg}。没有覆盖项目文件。`);};
const read=rel=>fs.readFileSync(path.join(root,rel));
const source=rel=>fs.readFileSync(path.join(bundle,rel));
const dest=rel=>path.join(root,rel);

const labHashes = {
  // Populated from the official locally distributed v5 package sources.
  'v5-on-v2': 'f4ee18648b375bfb2519bb3cecb7de641945555e8f67c1870d03662bba6c3b44',
  'v5-on-v3': '78f6b859c6b5db847820bb7185ceee5244ace9567e255e46115b5badabcb76c6',
};
const EARTH_SPIN_V2_HASH='ba78ff61cdd1a2e748f2623afa9ff6c9cdac7bea46ec33121655dda725618fb9';
const EARTH_SPIN_V3_HASH='fb635be98c9b3ce9c5efc6078d8f54e5ea52f6a736445556f7b7e8c7a8ba5642';
const imports="import { installResilienceFollowUi } from './ui/resilienceFollow.js';\n";
const attachMark='  const cleanupLab = installResilienceLab({ viewer: scene.viewer, dataManager: data.dataManager });';
const cleanupMark='      cleanupLab();';
const followMark='  const cleanupFollow = installResilienceFollowUi({ viewer: scene.viewer });';
const removeMark='      cleanupFollow();';
function modifyMain(s){
  if(s.includes(imports.trim()) || s.includes(followMark)) {
    if(s.includes(imports.trim()) && s.includes(followMark) && s.includes(removeMark))return s;
    stop('src/main.js 的 v6 接入代码只有部分存在，请检查手动改动');
  }
  if(s.split(attachMark).length!==2 || s.split(cleanupMark).length!==2)
    stop('src/main.js 与已知安装结构不一致');
  return s.replace("import { installResilienceLab } from './ui/resilienceLab.js';\n",
     "import { installResilienceLab } from './ui/resilienceLab.js';\n"+imports)
    .replace(attachMark,attachMark+'\n'+followMark)
    .replace(cleanupMark,removeMark+'\n'+cleanupMark);
}
try {
  if(!fs.existsSync(dest('package.json')))stop('请先进入 gods-eye-view 项目根目录');
  if(JSON.parse(read('package.json').toString()).name!=='gods-eye-view')stop('当前目录不是 gods-eye-view');
  const lab='src/ui/resilienceLab.js';
  if(!fs.existsSync(dest(lab)))stop('缺少韧性实验室，请先安装 v5');
  const labHash=hash(read(lab));
  const recognized=Object.entries(labHashes).find(([,v])=>v===labHash);
  if(!recognized)stop(`韧性实验室不是已知 v5 版本 (SHA256 ${labHash})；为保护你的修改，安装已停止`);
  const main='src/main.js', spin='src/ui/earthSpin.js', follow='src/ui/resilienceFollow.js';
  const currentMain=read(main).toString();
  const nextMain=modifyMain(currentMain);
  if(nextMain===currentMain && !currentMain.includes(imports.trim()))stop('main.js 未正确接入');
  const oldSpin=read(spin);
  const spinVariants=[
    {before:EARTH_SPIN_V2_HASH,after:source('src/ui/earthSpin.v2.js')},
    {before:EARTH_SPIN_V3_HASH,after:source(spin)},
  ];
  const chosenSpin=spinVariants.find(v=>hash(oldSpin)===v.before || hash(oldSpin)===hash(v.after));
  if(!chosenSpin)stop('earthSpin.js 不是标准 v2/v3 版本，停止以免覆盖你的自定义镜头环绕');
  const nextSpin=chosenSpin.after;
  const nextFollow=source(follow);
  if(fs.existsSync(dest(follow)) && hash(read(follow))!==hash(nextFollow))
    stop('resilienceFollow.js 已存在不同版本，不会覆盖');
  const updates=[
    {rel:main,old:Buffer.from(currentMain),next:Buffer.from(nextMain)},
    {rel:spin,old:oldSpin,next:nextSpin},
    {rel:follow,old:fs.existsSync(dest(follow))?read(follow):null,next:nextFollow},
  ].filter(x=>!x.old||hash(x.old)!==hash(x.next));
  if(!updates.length){console.log('[OK] v6 跟拍模式已安装，无需重复安装');process.exit(0);}
  console.log(`[OK] v5 标准版本 ${recognized[0]}；将更新：`);
  for(const update of updates)console.log(' ',update.rel);
  console.log('[OK] 不会修改 src/ui/resilienceLab.js、FAOSTAT 或仿真结果 JSON。');
  if(checkOnly){console.log('[OK] 预检查成功，尚未写入文件');process.exit(0);}
  const backupDir=dest('.resilience-v6-backup');
  for(const x of updates){
    if(!x.old)continue;
    const bak=path.join(backupDir,x.rel);
    fs.mkdirSync(path.dirname(bak),{recursive:true});
    if(!fs.existsSync(bak))fs.writeFileSync(bak,x.old,{flag:'wx'});
  }
  const done=[];
  try{
    for(const x of updates){
      fs.mkdirSync(path.dirname(dest(x.rel)),{recursive:true});
      const tmp=dest(x.rel)+'.v6-tmp';
      fs.writeFileSync(tmp,x.next);
      fs.renameSync(tmp,dest(x.rel));
      done.push(x);
      console.log('[UPDATED]',x.rel);
    }
  }catch(error){
    for(const x of done.reverse()){
      if(x.old)fs.writeFileSync(dest(x.rel),x.old);
      else fs.rmSync(dest(x.rel),{force:true});
    }
    throw error;
  }
  console.log('[OK] 已安装镜头跟拍：逐个目标 / 2～10 秒 / 手动操作暂停 / 与镜头环绕互斥。');
  console.log('[BACKUP] .resilience-v6-backup');
}catch(error){console.error(error.message);process.exitCode=1;}
