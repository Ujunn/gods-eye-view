#!/usr/bin/env python3
"""v8 static/installer behavior checks against the shipped v7 module."""
import hashlib
from pathlib import Path
import shutil
import subprocess
import tempfile

here=Path(__file__).resolve().parent.parent
baseline=Path('/mnt/data/gods-eye-resilience-v7/src/ui/resilienceMultiCrop.js')
payload=(here/'src/ui/resilienceMultiCrop.js').read_text()
assert "name:'水稻'" in payload
assert '水稻（精米）' not in payload
assert "rate=el('output','gev-crop-rate'" in payload
assert "output.textContent=Number.isFinite(val)?`${val.toFixed(1)}%`:'…';" in payload
assert "if(!selected.has(key)){output.textContent='—';continue;}" in payload
assert "body.append(cropTitle,cropGrid,selectGrid" in payload
assert 'gev-mini' not in payload
assert "'节点·蓄意'" in payload and "'边·随机'" in payload
assert "focusLine.htmlFor=focus.id" in payload
assert "modeLine.htmlFor=mode.id" in payload
assert "onFollowChange" in payload and "createResilienceAttackFollow" in payload
assert "function countFor" not in payload  # Keep v7's original `const countFor`
assert "const countFor=" in payload
subprocess.run(['node','--check',str(here/'src/ui/resilienceMultiCrop.js')],check=True)
subprocess.run(['node','--check',str(here/'apply.mjs')],check=True)
if not baseline.exists():
    print('PASS: v8 static layout and syntax checks; fixture installer test unavailable outside authoring environment')
    raise SystemExit(0)
with tempfile.TemporaryDirectory(prefix='gev-v8-test-') as d:
    root=Path(d)
    (root/'package.json').write_text('{"name":"gods-eye-view"}')
    target=root/'src/ui/resilienceMultiCrop.js'
    target.parent.mkdir(parents=True)
    shutil.copy(baseline,target)
    def apply(*args,ok=True):
        p=subprocess.run(['node',str(here/'apply.mjs'),*args],cwd=root,text=True,capture_output=True)
        assert (p.returncode==0)==ok,(p.stdout,p.stderr)
        return p
    before=hashlib.sha256(target.read_bytes()).hexdigest()
    assert apply('--check').returncode==0
    assert hashlib.sha256(target.read_bytes()).hexdigest()==before
    apply()
    assert target.read_text()==payload
    assert (root/'.resilience-v8-backup/src/ui/resilienceMultiCrop.js').read_bytes()==baseline.read_bytes()
    apply();apply('--check')
    assert target.read_text()==payload
    target.write_text(payload+'\n// custom\n')
    assert '本地' in apply(ok=False).stderr
    assert target.read_text().endswith('// custom\n')
print('PASS: v8 controls, retention binding, unchanged metrics, check/install/repeat/backup/conflict')
