#!/usr/bin/env node
// Install a focused v8 presentation-only update over the published v7 module.
// Refuse unknown local variants, back up exactly once and atomically replace one file.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const repo = process.cwd();
const pkg = path.dirname(fileURLToPath(import.meta.url));
const rel = 'src/ui/resilienceMultiCrop.js';
const expectedV7 = 'e5c5480df0873df18addfc938c187e7f96bb278985dd3667b08a1c13369f07d9';
const expectedV8 = 'bf4c4ba6511cd60b453a3f84e3c8a744a9a74eac8ea2dc07e6379a8d37d1a10f';
const checkOnly = process.argv.includes('--check');
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const fail = reason => { throw Error(`[STOP] ${reason}。没有覆盖任何项目文件。`); };
try {
  const metaPath = path.join(repo, 'package.json');
  if (!fs.existsSync(metaPath) || JSON.parse(fs.readFileSync(metaPath, 'utf8')).name !== 'gods-eye-view')
    fail('请先 cd 到 gods-eye-view 项目根目录');
  const target = path.join(repo, rel);
  if (!fs.existsSync(target)) fail('未发现 v7 四作物韧性实验室，请先安装 v7');
  const current = fs.readFileSync(target);
  const payload = fs.readFileSync(path.join(pkg, rel));
  if (sha(payload) !== expectedV8) fail('v8 安装包校验失败，请重新解压');
  const now = sha(current);
  if (now === expectedV8) {
    console.log('[OK] v8 已安装。再次执行不会覆盖或重复修改。');
    process.exit(0);
  }
  if (now !== expectedV7) fail('本地 resilienceMultiCrop.js 与原始 v7 不同，请先检查是否有自定义修改，并提供文件进行适配');
  console.log(`[v8] 仅更新 ${rel}`);
  console.log('[v8] 水稻简称；作物保留率放在复选框右侧；两个下拉并排；删除重复率卡片。');
  if (checkOnly) { console.log('[OK] 安装前检查通过，没有写入文件。'); process.exit(0); }

  const backup = path.join(repo, '.resilience-v8-backup', rel);
  fs.mkdirSync(path.dirname(backup), { recursive: true });
  if (fs.existsSync(backup)) {
    if (sha(fs.readFileSync(backup)) !== expectedV7) fail('v8 备份路径存在不同文件，请先检查备份');
  } else {
    fs.writeFileSync(backup, current, { flag: 'wx' });
  }
  const temp = `${target}.v8tmp-${process.pid}`;
  try {
    fs.writeFileSync(temp, payload);
    fs.renameSync(temp, target);
  } finally {
    if (fs.existsSync(temp)) fs.rmSync(temp, { force: true });
  }
  console.log('[OK] v8 安装完成。原文件备份：.resilience-v8-backup/src/ui/resilienceMultiCrop.js');
  console.log('[NEXT] npm run build && npm run dev');
} catch (error) {
  console.error(error.message);
  process.exitCode = 1;
}
